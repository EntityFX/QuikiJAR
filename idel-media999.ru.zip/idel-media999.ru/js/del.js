function del(text) {
	var msg="Вы действительно хотите удалить "+text+"?"; 
	if (confirm(msg)) {
		return true;
	} else {
		return false;
	}
}