<? //РЎРѕР»РѕРїРёР№ РђСЂС‚С‘Рј & Р®СЃСѓРїР·СЏРЅРѕРІ РўРёРјСѓСЂ )))
	header("Content: text/html; charset=utf8");
	require_once "includes/config.php";
	require_once "classes/kernel.php";
	require_once "includes/mysql_connect.php";
	$kernel = new TEntityFx();
	$kernel->go();
	//echo $_SERVER["REMOTE_ADDR"];
?>
