<? //Создаёт CAPTCHA
	require_once "../classes/captcha.php";
	$img=new TCaptcha(120,25);
	$img->create_captcha(6);
?>
