<?
	$r=mysql_connect(DB_HOST,DB_USER,DB_PASS);
	if (!$r) die("Не найден сервер БД");
	$db_selected=mysql_select_db(DB_NAME);
	if (!$db_selected) die("Не могу подключиться к БД");
	mysql_query("SET NAMES utf8");	
?>