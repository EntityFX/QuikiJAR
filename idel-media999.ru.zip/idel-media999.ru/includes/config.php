<?
	//database constants
	define("DB_HOST","localhost");
	define("DB_NAME","spektr");  
	define("DB_USER","root");         
	define("DB_PASS","");
?>
