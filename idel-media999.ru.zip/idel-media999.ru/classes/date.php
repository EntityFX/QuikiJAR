<?
	class TDate {
		private $month;
		
		function __construct() {
			$this->month=array("01"=>"Января","02"=>"Февраля","03"=>"Марта","04"=>"Апреля","05"=>"Мая","06"=>"Июня","07"=>"Июля","08"=>"Августа","09"=>"Сентября","10"=>"Октября","11"=>"Ноября","12"=>"Декабря");
		}
		
		public function get_month($mon) {
			return $this->month[$mon];
		}
		
		public function get_cool_date($timestamp) {
			$date=str_replace("0","",substr($timestamp,8,2));
			$month=$this->get_month(substr($timestamp,5,2));
			$year=substr($timestamp,0,4);
			$time=substr($timestamp,11,5);
			return "$date $month $year, $time";
		}
	}
?>