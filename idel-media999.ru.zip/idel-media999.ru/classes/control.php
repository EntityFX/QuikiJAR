<?
	require_once("string.php");
	
	class TConf {
		public function show_links($type) {
			$this->update($type,"links");
		}
		
		public function on_links() {
			return $this->check("links");
		}

		public function show_news($type) {
			$this->update($type,"news");
		}
		
		public function on_news() {
			return $this->check("news");
		}
		
		public function show_messages($type) {
			$this->update($type,"messages");
		}
		
		public function on_messages() {
			return $this->check("messages");
		}
		
		public function show_response($type) {
			$this->update($type,"resp");
		}
		
		public function on_response() {
			return $this->check("resp");
		}
		
		public function set_messges($val) {
			$this->set_val("tot_messages",$val);
		}
		
		public function get_messges() {
			return $this->get_val("tot_messages");
		}		
		
		public function set_images($val) {
			$this->set_val("tot_images",$val);
		}

		public function get_images() {
			return $this->get_val("tot_images");
		}
		
        public function on_tape()
        {
            return $this->check("tape");
        }
        
        public function show_tape($type) {
            $this->update($type,"tape");
        } 
               
		private function set_val($var,$val) {
			if (is_numeric($val)) {
				if ($val>=1 && $val<=99) {
					mysql_query("UPDATE `config` SET `value`=$val WHERE `var`='$var'");
				}
			}
		}
		
		private function check($var) {
			$query="SELECT `value` FROM `config` WHERE `var`='$var'";
			$res=mysql_query($query);
			$res_arr=mysql_fetch_array($res);
			if ($res_arr["value"]=="true") return "checked"; else return "";			
		}
		
		private function get_val($var) {
			$query="SELECT `value` FROM `config` WHERE `var`='$var'";
			$res=mysql_query($query);
			$res_arr=mysql_fetch_array($res);
			return $res_arr["value"];
		}
		
		private function update($type,$var) {
			if ($type) $query="UPDATE `config` SET `value`='true' WHERE `var`='$var'";
			else $query="UPDATE `config` SET `value`='false' WHERE `var`='$var'";
			mysql_query($query);
		}		
		
	}
	
	class TControl extends TConf {
		private $section_tree;
		private $tpl;
		private $krnel;
		private $str;
		public $total;
		
		function __construct() {
			$this->total=0;
			$this->str=new TNewString;
		}
		
        /**
        * Возвращает список разделов
        * @return Array
        */
        public function getSections()
        {
            $this->get_sec_subsec();
            return $this->section_tree;
        }
        
        /**
        * Строит список для дерева разделов
        * @access private
        * @var Array $this->section_tree Массив, хранящий список для дерева разделов
        */
		private function get_sec_subsec()
        {
			$sec_query=mysql_query("SELECT * FROM `section` ORDER BY `pos`");
			while($lines=mysql_fetch_array($sec_query))
            {
				$current_tree_node=htmlspecialchars($lines["title"]);
				$sec="?sec=".str_replace("/","",$lines["link"]);
				$this->section_tree[]=array("title" => $current_tree_node, "type" => 0, "sec" => $sec, "main" => $lines["main"], "link" => $lines["link"], "inv" => $lines["type"]);
				$subsec_query=mysql_query("SELECT * FROM `subsection` WHERE `p_id`=$lines[id] ORDER BY `pos` ASC");
				while($sublines=mysql_fetch_array($subsec_query))
                {
					$current_tree_node=$sublines["title"];
					$subsec=explode("/",$sublines["link"]);
                    $parentLink=substr($lines["link"],1,strlen($lines["link"])-2);
                    $childrenLink=substr($sublines["link"],1,strlen($sublines["link"])-2);
					$this->section_tree[]=array("title" => $current_tree_node, "type" => 1, "sec" => "?sec=$parentLink&amp;subsec=$childrenLink", "link" => $sublines["link"], "pid" => $sublines["p_id"], "parent" => $parentLink);
					//0 - section, 1 - subsection
					$this->total++;
				}
			}
		}
		
        /**
        * Формирует html дерево ссылок для редактирования и удаления
        * @access public
        * @return String
        */
		public function make_tree()
        {
			$this->get_sec_subsec();
			$list="<table>\n";
			if ($this->section_tree!=NULL)
            {
				foreach($this->section_tree as $key => $val)
                {
					if ($val["type"]==1)
                    {
						$list=$list."<tr><td>&nbsp;&nbsp;&nbsp;<a href=\"/$val[parent]$val[link]\"><span class=\"sel\">".$val["title"]."</span></a></td>
                        <td><a href=\"/control/movedown/".$val["sec"]."\"><span class=\"sel_arr\">&#9660;</span></a></td>
                        <td><a href=\"/control/moveup/".$val["sec"]."\"><span class=\"sel_arr\">&#9650;</span></a></td><td></td>";
						$list=$list."<td><a href=\"/control/edit/".$val["sec"]."\">Ред</a></td><td><a href=\"/control/del/".$val["sec"]."\" class=\"del\" onclick=\"return del('$val[title]');\">X</a></td></tr>\n";
					}
					else
                    {
						if ($val["inv"]==1) $list=$list."<tr><td><a href=\"$val[link]\" class=\"inv\">".$val["title"]."</a>";
						else  $list=$list."<tr><td><a href=\"$val[link]\">".$val["title"]."</a>";
						$list=$list."</td><td><a href=\"/control/movedown/".$val["sec"]."\">&#9660;</a></td><td><a href=\"/control/moveup/".$val["sec"]."\">&#9650;</a></td>";
						if ($val["main"]==1) $list=$list."<td>&#9679;</td>"; else $list=$list."<td></td>";
						$list=$list."<td><a href=\"/control/edit/".$val["sec"]."\">Ред</a></td><td><a href=\"/control/del/".$val["sec"]."\" class=\"del\" onclick=\"return del('$val[title]');\">X</a></td></tr>\n";
					}
				}
			}
			$list=$list."</table>";
			return $list;
		}
		
		/**
        * Выполняет подстановку значений элементов разделов/подразделов в шаблон
        * @access public
        * @param TTemplator $tpl ссылка на объект шаблона
        * @param Array $link url разделов
        * @param Bool $link (true - подраздел; false - раздел)
        * @return String контент разделов/подразделов
        */
        public function get_for_edit(&$tpl,$link,$flag)
        {
            if ($flag)
            {
                $editing_query=mysql_query("SELECT * FROM `subsection` WHERE `link`='/$link[childrenLink]/' AND `p_id`=(SELECT `id` FROM `section` WHERE `link`='/$link[parentLink]/')");
            }
            else 
            {
                $editing_query=mysql_query("SELECT * FROM `section` WHERE `link`='/$link/'");
            }
            $editing_array=mysql_fetch_array($editing_query);
			$tpl->set_var_value("HEADER",$editing_array["title"]);
			$tpl->set_var_value("TEXTAREA",$editing_array["text"]);
            $tpl->set_var_value("URL",$editing_array["name"]);
            $tpl->set_var_value("TITLE",$editing_array["title_key"]); 
			return $editing_array[text];
		}
		
        /**
        * Сохраняет редактируемый текст
        * @access public
        * @param String|Array $link url разделов
        * @param Bool $link (true - подраздел; false - раздел)
        * @return Null null
        */        
		public function save_edit($link,$flag)
        {
			$fl1=0;
			$fl2="";
			if ($flag)
            {
                $s="`subsection`";
                $countQuery="SELECT COUNT(*) as `ex` FROM $s WHERE `link`='/$link[childrenLink]/'";
            } 
			else {
				$s="`section`";
                $countQuery="SELECT COUNT(*) as `ex` FROM $s WHERE `link`='/$link/'";
			}
			$check_query=mysql_query($countQuery);
			$check_array=mysql_fetch_array($check_query);
			if ($check_array["ex"]!=0) {
				if (TNewString::check_symbols($_POST["title"]))
                {
                    $tit=$_POST["title"];
                    $txt=$_POST["article"];
                    $name=$_POST["url"];
                    $keywords=trim($_POST["keywords"]);
					if (!$flag)
                    {
						$main_check=$_POST["main"];
                        if ($main_check=="on")
                        {
                            mysql_query("UPDATE $s SET `main`=0");
							$fl1=1; 
						} else $fl1=0;
						if ($_POST["invisible"]) $fl2=1;
                        else $fl2=0; //0 - РѕР±С‹С‡РЅС‹Р№, 1 - СЃРєСЂС‹С‚С‹Р№
                        $url="/".$_POST["url"]."/"; 
                        if ($keywords=="")
                        {
                            $keywords=$tit;    
                        } 
						$save_query="UPDATE $s SET `title`='$tit', `text`='$txt',`main`=$fl1,`type`=$fl2, `title_key`='$keywords',`link`='$url',`name`='$name' WHERE `link`='/$link/'";
					} 
                    else 
                    {
                        $section=$_GET["sec"];
                        $new_link="/$name/";
                        $save_query="UPDATE $s SET `title`='$tit', `text`='$txt', `title_key`='$keywords',`link`='$new_link',`name`='$name' WHERE `link`='/$link[childrenLink]/' AND `p_id`=(SELECT `id` FROM `section` WHERE `link`='/$link[parentLink]/')";
                        //die($save_query);
                    }
					mysql_query($save_query);
					header("Location: /control/show/");
				}
                else header("Location: /error/4/");
			}
            else header("Location: /error/3/"); 
		}
        
		/**
        * Добавляет раздел
        * @return Null null
        */
		public function add_sec()
        {
			if ($this->str->check_symbols($_POST["sec"]) &&  strlen($_POST["sec"])>2)
            {
				$s_title=$_POST["sec"];
				$name=$this->str->encodestring(($s_title));
				$link="/$name/";
				if ($this->isExist($link,false)) header("Location: /error/5/");
                else
                {
				    if ($this->checkUrl($name))
                    {
                        switch ($_POST["insert"])
                        {
						    case "first":
							    mysql_query("UPDATE `section` SET pos = pos+1 ORDER BY id DESC");
							    $add_query="INSERT INTO `section` VALUES(0,'$name','$link','$s_title','',0,'',1,0)";
							    break;
						    case "last":
							    $last_query=mysql_query("SELECT MAX(`pos`) as `pos` FROM `section`");
							    $last_arr=mysql_fetch_array($last_query);
							    $last_arr["pos"]=$last_arr["pos"]+1;
							    $add_query="INSERT INTO `section` VALUES(0,'$name','$link','$s_title','',0,'',$last_arr[pos],0)";
							    break;
						    case "before":
							    $before=$_POST["section"];
							    $before_query=mysql_query("SELECT `pos` FROM `section` WHERE `id`='$before'");
							    $before_arr=mysql_fetch_array($before_query);
							    mysql_query("UPDATE `section` SET pos = pos+1 WHERE `pos`>$before_arr[pos] ORDER BY id DESC");
							    $before_arr["pos"]=$before_arr["pos"]+1;
							    $add_query="INSERT INTO `section` VALUES(0,'$name','$link','$s_title','',0,'',$before_arr[pos],0)";
							    break;
					    }
                    }
                    else
                    {
                        $exception=new Exception("",1);
                        throw $exception;
                    } 
					mysql_query($add_query);
					header("Location: /control/edit/?sec=$name");
				}
			}
            else header("Location: /control/show/");
		}
        
        /**
        * Добавляет подраздел
        * @return Null null
        */		
		public function add_subsection()
        {
            if ($this->str->check_symbols($_POST["name_subsec"]) &&  strlen($_POST["name_subsec"])>2)
            {
                $s_title=$_POST["name_subsec"];
                if (!$this->checkUrl($s_title))
                {
                    $ex=new Exception("",1);
                    throw $ex;
                }                
				$name=$this->str->encodestring($s_title);
				$sec_title=$_POST["section"];
                $sec=mysql_query("SELECT `link`,`id`,`name` FROM `section` WHERE `id`='$sec_title'");
				$sec_row=mysql_fetch_array($sec);
                $link=$sec_row["link"];// die(var_dump($_POST));
                $linkArray=array("parentLink" => substr($link,1,strlen($link)-2), "childrenLink" => $s_title);
				if ($this->isExist($linkArray,true)) 
                {
                    header("Location: /error/5/"); 
                }
                else 
                { 
                    $last_query=mysql_query("SELECT MAX(`pos`) as `pos` FROM `subsection` WHERE `p_id`=$sec_row[id]");
                    //die("SELECT MAX(`pos`) as `pos` FROM `subsection` WHERE `p_id`=$sec_row[id]");
					$last_arr=mysql_fetch_array($last_query);
					$last_arr["pos"]+=1;
					$add_query="INSERT INTO `subsection` VALUES(0,'$s_title','/$s_title/','$s_title','',0,'',$last_arr[pos],$sec_row[id])";
					mysql_query($add_query);
					header("Location: /control/edit/?sec=$sec_row[name]&subsec=$name");
				}
			}
            else header("Location: /control/show/");
		}
        
        /**
        * Удаляет раздел
        * @access public
        * @param String|Array $link url разделов
        * @param Bool $link (true - подраздел; false - раздел)
        * @return Null null
        */         
		public function del_edit($link,$flag)
        {
			$pos_query="";
            $pid=0;
			if ($flag) 
            {
                $s="`subsection`";
                $check_query=mysql_query("SELECT COUNT(*) as `ex` FROM $s WHERE `link`='/$link[childrenLink]/'");
                $pid_query=mysql_query("SELECT `id` FROM `section` WHERE `link`='/$link[parentLink]/'");
                $pos_array=mysql_fetch_array($pid_query);
                $pid=$pos_array["id"];
            }
            else 
            {
                $s="`section`";
                $check_query=mysql_query("SELECT COUNT(*) as `ex` FROM $s WHERE `link`='/$link/'");
            }
			$check_array=mysql_fetch_array($check_query);
			if ($check_array["ex"]!=0)
            {
				if (!$flag)
                {
					$del_query1="DELETE FROM `subsection` WHERE `p_id`=(SELECT `id` FROM `section` WHERE `link`='/$link/')";
					mysql_query($del_query1);
					$pos_query=mysql_query("SELECT `pos` FROM `section` WHERE `link`='/$link/'");
                    $del_query=mysql_query("DELETE FROM $s WHERE `link`='/$link/'");
				} 
                else
                {
                    $pos_query=mysql_query("SELECT `pos` FROM `subsection` WHERE `link`='/$link[childrenLink]/' AND `p_id`=$pid");
                    $del_query=mysql_query("DELETE FROM $s WHERE `link`='/$link[childrenLink]/' AND `p_id`=$pid");
                }
				$pos_array=mysql_fetch_array($pos_query);
				$del_pos=$pos_array["pos"];
				if (!$flag)
                {
					mysql_query("UPDATE `section` SET pos=pos-1 WHERE `pos`>$del_pos ORDER BY `pos` ASC");
				} else {
                    //die("UPDATE `subsection` SET pos=pos-1 WHERE `pos`>$del_pos AND `p_id`=(SELECT `id` FROM `section` WHERE `link`='/$link[parentLink]/') ORDER BY `pos` ASC");
					mysql_query("UPDATE `subsection` SET pos=pos-1 WHERE `pos`>$del_pos AND `p_id`=$pid ORDER BY `pos` ASC");
				}
				header("Location: /control/show/");
			}
            else header("Location: /error/3/"); 	
		}
		
        /**
        * HTML список разделов
        * @access public
        * @return String
        */
		public function get_section_list()
        {
			$list="";
			$check_query=mysql_query("SELECT COUNT(*) as `ex` FROM `section`");
			$check_array=mysql_fetch_array($check_query);
			if ($check_array["ex"]!=0) {
				$sec_query=mysql_query("SELECT * FROM `section` ORDER BY `pos` ASC");
				while($sublines=mysql_fetch_array($sec_query))
                {
					$list=$list."<option value=\"$sublines[id]\">$sublines[title]</option>\n";
				}				
			}
			return $list;
		}
        
        /**
        * HTML список подразделов
        * @access public
        * @return String
        */		
		public function get_subsection_list()
        {
			$list="";
			$check_query=mysql_query("SELECT COUNT(*) as `ex` FROM `subsection`");
			$check_array=mysql_fetch_array($check_query);
			if ($check_array["ex"]!=0)
            {
				$sec_query=mysql_query("SELECT * FROM `subsection`");
				while($sublines=mysql_fetch_array($sec_query))
                {
					$list=$list."<option> $sublines[title]</option>\n";
				}				
			}
			return $list;
		}
		
        private function isExist($link,$flag)
        {
            if ($flag)
            {
                $resource=mysql_query("SELECT IF((SELECT COUNT(*) FROM `subsection` WHERE `link`='/$link[childrenLink]/' 
                AND `p_id`=(SELECT `id` FROM `section` WHERE `link`='/$link[parentLink]/'))=1,'true','false') AS `res`"); 
            } 
            else
            {
                $resource=mysql_query("SELECT IF((SELECT COUNT(*) FROM `section` WHERE `link`='/$link/')=1,'true','false') AS `res`");
            }
            $field=mysql_fetch_assoc($resource);
            if ($field["res"]=="true") return true; else return false;               
        }
        
		private function move($link,$type) {
			if ($type==1)
            {
				$sub_str="MAX(`pos`)";
				$mpl=1;
			} 
            else
            {
				$sub_str="MIN(`pos`)";
				$mpl=-1;			
			}
			$sec="/$link/";
			$max_query=mysql_query("SELECT $sub_str as `pos` FROM `section`");
			$max_arr=mysql_fetch_array($max_query);
			$max_pos=$max_arr["pos"];
			$cur_query=mysql_query("SELECT `pos` FROM `section` WHERE `link`='$sec'");
			$cur_arr=mysql_fetch_array($cur_query);
			$cur_pos=$cur_arr["pos"];
			if ($max_pos!=$cur_pos)
            {
				$next_pos=$cur_pos+1*$mpl;
				$upd_query=mysql_query("UPDATE `section` SET `pos`=-1 WHERE `pos`=$cur_pos");
				$upd_query=mysql_query("UPDATE `section` SET `pos`=$cur_pos WHERE `pos`=$next_pos");
				$upd_query=mysql_query("UPDATE `section` SET `pos`=$next_pos WHERE `pos`=-1");
			}
			header("Location: /control/show/");		
		}
		
        private function move_subsec($link,$type)
        {
            if ($type==1) {
                $sub_str="MAX(`pos`)";
                $mpl=1;
            } else {
                $sub_str="MIN(`pos`)";
                $mpl=-1;            
            }
            $max_query=mysql_query("SELECT $sub_str as `pos`, `p_id` FROM `subsection` WHERE `p_id`=(SELECT `id` FROM `section` WHERE `link`='/$link[parentLink]/') GROUP BY `p_id`");
            $max_arr=mysql_fetch_array($max_query);
            $max_pos=$max_arr["pos"];
            $p_id=$max_arr["p_id"];
            $cur_query=mysql_query("SELECT `pos` FROM `subsection` WHERE `link`='/$link[childrenLink]/' AND `p_id`=$p_id");
            $cur_arr=mysql_fetch_array($cur_query);
            $cur_pos=$cur_arr["pos"];
            if ($max_pos!=$cur_pos) {
                $next_pos=$cur_pos+1*$mpl;
                $upd_query=mysql_query("UPDATE `subsection` SET `pos`=-1 WHERE `pos`=$cur_pos AND `p_id`=$p_id");
                $upd_query=mysql_query("UPDATE `subsection` SET `pos`=$cur_pos WHERE `pos`=$next_pos AND `p_id`=$p_id");
                $upd_query=mysql_query("UPDATE `subsection` SET `pos`=$next_pos WHERE `pos`=-1 AND `p_id`=$p_id");
            }
            header("Location: /control/show/");        
        }
		
        public function move_up($link,$flag)
        {
            if ($flag) $this->move($link,1); else $this->move_subsec($link,1);
        }
        
        public function move_down($link,$flag)
        {
            if ($flag) $this->move($link,0);
            else $this->move_subsec($link,0);
        }    		
		
        /**
        * Проверка корневой ли раздел
        * 
        * @param String $name Имя раздела  
        * @return Integer
        */
		public function is_main($name)
        {
			$query="SELECT `main` FROM `section` WHERE `name`='$name'";
			$query_res=mysql_query($query);
			$row=mysql_fetch_array($query_res);
			return $row["main"];
		}
		
        /**
        * Определяет, является ли видимым раздел
        * 
        * @param String $name Имя раздела
        * @return Integer
        */
		public function is_invisible($name)
        {
			$query="SELECT `type` FROM `section` WHERE `name`='$name'";
			$query_res=mysql_query($query);
			$row=mysql_fetch_array($query_res);
			return $row["type"];
		}
        
        private function checkUrl($str)		
        {
            if (preg_match("/^[\w-]*$/",$str)) return true; else false;
        }
	}
?>