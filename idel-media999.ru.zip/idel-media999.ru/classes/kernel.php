<?
require_once("templator.php");
require_once("control.php");
require_once("auth.php");
require_once("links.php");
require_once("string.php");
require_once("messages.php");
require_once("img_controling.php");
require_once("captcha.php");
require_once("news.php");
require_once("question.php");
require_once("tape.php");
require_once("cat_control.php");
require_once("anque.php");
/**
* Класс ядра. Сканирует url, строит меню, работает с получением данных из БД
*/
class TEntityFx {
	private $url;
	private $url_array;
	private $main_id;
	private $current;
    private $keywords; //Ключевые слова в <title></title>
	private $current_sub;
	private $text;
	private $cfg;
	private $cur_section;
    private $sectionUrl;
    private $logo;
	
    /**
    * Класс ядра. Управляет ссылками
    * 
    */
	function __construct() {
		$this->url=substr($_SERVER['REQUEST_URI'],1);
		$this->url_array=explode("/",$this->url);
        if ($this->url_array[count($this->url_array)-1]=="")
        {
            array_pop($this->url_array);
        }
		if ($this->url_array[0]=="") {
			$root=mysql_query("SELECT `name`,`id`,`title` FROM `section` WHERE `type`!='1' AND `main`=1");
			$res_root=mysql_fetch_array($root);
			$this->main_id=$res_root["id"];
			$this->current_sec=$res_root[0];
			$this->current=$res_root[0];
            $this->logo=$res_root["title"];
		} else {
			$this->current_sub=$this->url_array[count($this->url_array)-1];
			$this->current=$this->url_array[count($this->url_array)-1];
		}
	}
	
	function get_request() {
		return $this->url;
	}
	
	function go() {
		$val=$this->url_array[0];
		if ($val=="") $val=$this->current;
		$res_sec_query=mysql_query("SELECT COUNT(*) FROM `section` WHERE `name` = '$val'");
		$cnt_sec=mysql_fetch_array($res_sec_query);
		$tpl=new TTemplator;
		$this->cfg=new TConf;
		$auth=new TAuth;
		if (!$tpl->get_template("templates/main.tpl")) echo "Не удалось загрузить шаблон";
		if ($cnt_sec["COUNT(*)"]==0) {
			$tpl->set_var_value("SUBMAIN_UL","");
			switch ($val) {
				case "error":
					$error_type=$this->url_array[1];
					$text="";
					switch ($error_type) {
						case "404":
							$text="<h2>Ошибка 404</h2><strong class=\"error\">ЗАПРАШИВАЕМАЯ ВАМИ СТРАНИЦА НЕ СУЩЕСТВУЕТ</strong>";
							break;
						case "1":
							$text="<h2>Ошибка авторизации</h2><strong class=\"error\">Неверный пароль</strong>";
							break;
						case "2":
							$text="<h2>Ошибка авторизации</h2><strong class=\"error\">Неверный логин</strong>";
							break;
						case "3":
							$text="<h2>Ошибка изменения раздела</h2><strong class=\"error\">Раздел не существует</strong>";
							break;
						case "4":
							$text="<h2>Ошибка изменения раздела</h2><strong class=\"error\">Недопустимые символы в заголовке</strong>";
							break;							
						case "5":
							$text="<h2>Ошибка изменения раздела</h2><strong class=\"error\">Раздел с таким именем уже существует. Проверьте название заголовка.</strong>";
							break;	
						case "6":
							$text="<h2>Ошибка загрузки файла</h2><strong class=\"error\">Не удалось загрузить изображение.</strong>";
							break;	
						case "7":
							$text="<h2>Код на картинке</h2><strong class=\"error\">Вы ввели неправильный код на картинке.Повторите снова.</strong>";
							break;			
						case "8":	$text="<h2>Ошибка загрузки файла</h2><strong class=\"error\">Разрешается загружать только изображения GIF, JPEG, PNG.</strong>";
							break;
						default: header("Location: /error/404/");
					}
					$this->text=$text;
					if (!$tpl->get_template("templates/error.tpl")) echo "Не удалось загрузить шаблон";
					break;
				case "control":
					if ($auth->check_user()) {
						include_once "kernel.controling.php";
					} else header("Location: /");
					break;
				case "messages":
					if (!$tpl->get_template("templates/messages.tpl")) echo "Не удалось загрузить шаблон";	
					$tpl->set_var_value("LOGO","<h2>Отправка сообщения</h2>");
					$tpl->set_var_value("USEROK",$auth->get_user());
					break;
				case "send":
					if (TCaptcha::check_captcha($_POST["code"])) {
						$messenger=new TMessages();
						$messenger->send($_POST["name"],$_POST["tel"],$_POST["e_mail"],$_POST["message"]);
						header("Location: /messages");
					} else header("Location: /error/7");
					break;
				case "admin":
					if (!$tpl->get_template("templates/form_login.tpl")) echo "Не удалось загрузить шаблон";
					break;
				case "login":
					$auth_res=$auth->check_login();
					switch ($auth_res) {
						case -1:
							header("Location: /error/1");
							break;
						case 0:
							header("Location: /error/2");
							break;
						case 1:
							header("Location: /control");
							break;
					}
					break;
				case "unlogin":
					$auth->close_session();
					header("Location: /");
					break;
				case "news":
					if ($this->cfg->on_news()=="checked") {
                        $this->logo="Новости";
						$news = new TNews();
						$this->text=$news->show_some_news_or_one_u();
					} else $tpl->set_var_value("SURVEY","Отключено");
					break;	
				case "question":
					$response=new TQuestion;
					if ($this->cfg->on_response()=="checked") {
						switch ($this->url_array[1]) {
							case "all":
								$this->text="<h2>Просмотр опросов</h2>".$response->show_all_qs_u();
								break;	
							case "vote":
								$response->vote_u();
								header("Location: /question/all");
								break;
						}
					}
					break;
                case "answer":
                    $answer=new AnswerQuestion("/answer/");
                    $this->text=$answer->userQuests();
                    $this->text.=$answer->addQuestion($_POST["name"],$_POST["mail"],$_POST["question"]);
                    $this->keywords=$this->logo="Вопрос-ответ";
                    break;
                case "sitemap":
                    $this->keywords=$this->logo="Карта сайта";
                    $this->text=$this->siteMap();
                    break;
				default:
					if ($this->url_array[0]!="") header("Location: /error/404/");
			}
		} else {
			$res_sec_query=mysql_query("SELECT * FROM `section` WHERE `name` = '$val' ");
			$section_info=mysql_fetch_array($res_sec_query);
			$this->main_id=$section_info["id"];
			$this->cur_section=$section_info["name"];
            $this->logo=$section_info["title"];
			if (count($this->url_array)>1) {
				$subval=$this->url_array[1];
				$get_sublink=mysql_query("SELECT COUNT(*) FROM `subsection` WHERE `name`='$subval'");
				$subsection_count=mysql_fetch_array($get_sublink);
				if ($subsection_count["COUNT(*)"]==0) header("Location: /error/404/");
				else {
                    $par=$this->cur_section;
					$get_sublink=mysql_query("SELECT * FROM `subsection` WHERE `name`='$subval' AND `p_id`=(SELECT `id` FROM `section` WHERE `link`='/$par/')");
					$subsection_info=mysql_fetch_array($get_sublink);
					$this->text=$subsection_info["text"];
                    $this->keywords=$subsection_info["title_key"];
				}
			} else 
            {
                $this->text=$section_info["text"];
                $this->keywords=$section_info["title_key"];
            }
		}
        $tpl->set_var_value("LOGO",$this->logo);
		$tpl->set_var_value("MAIN_UL",$this->do_main());
		$tpl->set_var_value("SUBMAIN_UL",$this->do_submain());
		if ($this->cfg->on_response()=="checked") {
			$response=new TQuestion;
			$rspns=$response->show_one_q_u();
			$tpl->set_var_value("SURVEY",$rspns);
		} else $tpl->set_var_value("SURVEY","Отключено<br>");
		if ($this->cfg->on_news()=="checked") {
			$news=new TNews;
			$n_str=$news->show_simple_news();
			$tpl->set_var_value("NEWS",$n_str);
		} else $tpl->set_var_value("NEWS","Отключено");		
		if ($this->cfg->on_links()=="checked") {
			$links=new Tlinks;	
			$lnk_txt=$links->show();
		} else $lnk_txt="";	
		$tpl->set_var_value("LINKS",$lnk_txt);
		if (!$auth->check_user()) {
			$formlog=$tpl->get_from_file("templates/form_login.tpl");
		} else $formlog="";
		$catalogue=new Cat_ctrl(null);
		$tpl->set_var_value("CATALOGUE",$catalogue->makeTree());
        $tpl->set_var_value("KEYWORDS",$this->keywords);
		$tpl->set_var_value("TPL_TEXT",$this->text);
		$tpl->set_var_value("YEAR",date("Y"));
        if ($this->cfg->on_tape()=="checked")
        {
		    $tp=new Tape();
            $tapeTPL=new TTemplator();
            $tapeTPL->get_template("templates/megaTape.tpl");
		    $tapeTPL->set_var_value("TAPE_UL",$tp->get_ul(5));
            $tpl->set_var_value("MEGATAPE",$tapeTPL->go_template());
        } 
        else
        {
            $tpl->set_var_value("MEGATAPE","");    
        }
		echo $tpl->go_template();
	}
	
	function do_main() {
		$get_link=mysql_query("SELECT * FROM `section` WHERE `type`!='1' ORDER BY `pos`");
		$arr=$this->get_sql_array($get_link);
		$arr_txt=$this->get_links_list($arr,'menu',true);
		return $arr_txt;
	}
	
	function do_submain() {
		$get_link=mysql_query("SELECT * FROM `subsection` WHERE `p_id`=$this->main_id ORDER BY `pos`");
		$arr=$this->get_sql_array($get_link);
		if (count($arr)>0) {
			//if ($this->current!="") $this->cur_section=$this->current;
			$cur_raz_name=mysql_query("SELECT `title`,`link`,`type` FROM `section` WHERE `name` = '$this->cur_section'");
			$my=mysql_fetch_array($cur_raz_name);
			$arr_txt="<div class=\"block\"><div class=\"htwo\"><h2>$my[title]</h2></div>";
            if ($my["type"]==1) return "";
            $this->sectionUrl=substr($my["link"],0,strlen($my["link"])-1);
            $arr_txt.=$this->get_links_list($arr,'sublink',false)."</div>";
		}
        return $arr_txt;
	}
//здесь куется главное меню
    function get_links_list(&$arr,$css_class,$mode_admin) {
        $counter=count($arr);
		$str="";
        $parLink=$this->sectionUrl;
        for($i=0;$i<$counter;$i++) {
            $sub_a=$arr[$i];
			$title=/*htmlspecialchars*/ $sub_a["title"];
			if ($css_class=='menu') {//die($sub_a["name"]." --- ".$this->current);
				if ($sub_a["name"]==$this->current) $cur="<li class=\"curr\">$title</li>"; 
				else if ($sub_a["name"]==$this->cur_section) $cur="<li id=\"current\"><a href=\"$parLink$sub_a[link]\">$title</a></li>";
				else $cur="\n<li><a href=\"$parLink$sub_a[link]\">$title</a></li>";
			} else {
				if ($sub_a["name"]==$this->current_sub) $cur="<li><a href=\"\">$title</a></li>";
				else $cur="\n<li><a href=\"$parLink$sub_a[link]\">$title</a></li>";
			}
			$str=$str.$cur;
        }
        if ($css_class=='link') {
            $str.="<li><a href=\"/answer/\">Вопрос-ответ</a></li>";
        }
		$adm=new TAuth;
		if ($adm->check_user() && $mode_admin) {
			if ($this->url_array[0]=="control") {
				$str=$str."<li><a href=\"/control/\">Управление</strong></a></li>";
			} else $str=$str."<li><a href=\"/control/\">Управление</a></li>";
		}
		if ($counter>0) $str="<ul class=\"$css_class\">".$str."</ul>";
        return $str;     
    }
	
    private function siteMap()
    {
        $control=new TControl();
        $resArr=$control->getSections();
        $res="<ul>";
        $lastLevel=0;
        foreach($resArr as $key => $value)
        {
            if ($lastLevel==0 && $value["type"]==1)
            {
                $res.="<li><ul>\r";
            }
            else if ($lastLevel==1 && $value["type"]==0)
            {
                $res.="</ul></li>\r";
            }
            if ($value["type"]==0)
            {
                $parent=$value["link"];
                $link=$parent;
            }
            else
            {
                $link=$parent.substr($value["link"],1);    
            }
            $res.="\t<li><a href=\"$link\">$value[title]</a></li>\r";
            $lastLevel=$value["type"];    
        }
        $res.="</ul>";
        return $res;
        //var_dump($resArr);    
    }
    
	function get_sql_array($query_res) {
        while($lines=@mysql_fetch_array($query_res)) {
            $res[]=$lines;
        }
        return $res;
    }
	
	function get_main() {
		$get_link=mysql_query("SELECT * FROM `section` WHERE `main`='1'");
		$subsection_info=mysql_fetch_array($get_link);
		$this->main_id=$subsection_info["id"];
		return $subsection_info["text"];
	}
}

?>