<?
	require_once("control.php");
	require_once("date.php");
	class TMessages {
		public $count_;
		private $max=1;
		private $id;
		
		function __construct($id=0) {
			$this->count_=$this->count();
			$conf=new TConf;
			$this->max=$conf->get_messges();
			if (!is_numeric($id)) $id=0;
			$this->id=$id;
		}
		
		public function send($fio,$tel,$e_mail,$message) {
			$message=htmlspecialchars($message);
			$tel=htmlspecialchars($tel);
			$e_mail=htmlspecialchars($e_mail);
			$tel=htmlspecialchars($tel);
			$query="INSERT INTO `messages` VALUES(0,NOW(),'$fio','$tel','$mail','$message')";
			mysql_query($query);
		}
		
		public function getmsg() {
			$pg=($this->id-1)*$this->max;
			$sel_query="SELECT * FROM `messages` ORDER BY `id` DESC LIMIT $pg,$this->max";
			$sel_res=mysql_query($sel_query);
			return $this->make($sel_res);
		}
		public function links_line() {
			$tot=ceil($this->count()/$this->max);
			for($i=1;$i<=$tot;++$i) {
				if ($this->id==$i) $str=$str."<b class=\"sel\"> $i</b>"; else $str=$str." <a href=\"/control/messages/?id=$i\">$i</a>";
			}
			if ($i<=2) $str="";
			return $str;
		}
		
		public function delete_link($id) {
			if (!is_numeric($id)) $id=0;	
			$query="DELETE FROM `messages` WHERE `id`=$id";
			mysql_query($query);
		}
		
		private function count() {
			$query="SELECT COUNT(*) as `count` FROM `messages`";
			$res_query=mysql_query($query);
			$res_array=mysql_fetch_array($res_query);
			return $res_array["count"];
		}
		
		private function make($sel_res) {
			$str="";
			$i=1;
			$date=new TDate();
			while ($arr=mysql_fetch_array($sel_res)) {
				$mes_date=$date->get_cool_date($arr["Time"]);
				$str=$str.
				"<a href=/control/msgdel/?id=$arr[id] class=\"del\">X</a><br>\n
				<span class=\"date\">$mes_date</span><br>\n<strong>№$i</strong><br>\n
				<strong>От:</strong> $arr[FIO]<br>\n
				<strong>Тел:</strong> $arr[Tel]<br>\n
				<strong>E_mail:</strong> $arr[Mail]<br>\n
				<strong>Текст сообщения:</strong> $arr[message]<br>\n
				<hr>";
				$i++;
			}
			if ($str=="") $str="Сообщений нет";
			return $str;
		}
	}
?>