<?
    /*
		0 - неправильный логин
		-1 - неправильный пароль
		1 - всё ок, логин записан в сессию
	*/
	class TAuth {
		function __construct() {
			session_start();	
		}
		
        function check_login() {
            $res_code = 0;
            $login_p = $_POST["login"];
            $password_p = $_POST["pswrd"];
            
            if ($login_p != "")  {            
                $users_sec_query=mysql_query("SELECT `login`,`password` FROM `users` WHERE `login` = '$login_p'");
                $cnt_sec=mysql_fetch_array($users_sec_query);
                if (!$cnt_sec["login"]) $res_code = 0;                   
                else {
					$login_chk = $cnt_sec["login"];
					$password_chk = $cnt_sec["password"];
					if (md5(md5($password_p).sha1($password_p)."EntityFX") != $password_chk) $res_code = -1;
					else
                    {
                        $_SESSION['username'] = $login_chk;
                        $error_login = $_SESSION['username'];
						$res_code = 1;
                    }
                };
            } else $res_code = 0;
			return $res_code;
        }
        
		public function add_user($login,$password) {
			$encrypt_pass=md5(md5($password).sha1($password)."EntityFX");
			mysql_query("INSERT INTO `users` SET `login`='$login',`password`='$encrypt_pass'");
			return 1;
		}
		
        public function close_session() {
            unset($_SESSION['username']);
            session_destroy();
        }
        
		public function check_user() {
			if (isset($_SESSION['username'])) $res=true; else $res=false;
			return $res;
		}

		public function get_user() {
			return $_SESSION['username'];
		}
		
        private $login="";
        private $pass="";
        private $login_chk="";
        private $password_chk="";
    };
?>