<? //Шаблонизатор
	class TTemplator {
		function get_template($f_name) {
			if (!file_exists($f_name)) return false;
			else {
				$this->code=file_get_contents($f_name);
				return true;
			}
		}
		
		function set_var_value($tpl_var,$var_value) {
			$tpl_var='['.$tpl_var.']';
			$this->variables[$tpl_var]=$var_value;
		}
		
		function go_template() {
			foreach($this->variables as $tpl_var => $var_value) {
				$this->code=str_replace($tpl_var,$var_value,$this->code);
			}
			return $this->code;
		}
		
		function get_from_file($f_name) {
			if (!file_exists($f_name)) return "1";
			else {
				return file_get_contents($f_name);
			}
		}
		
        var $variables=array();
        var $code="";
	};
?>