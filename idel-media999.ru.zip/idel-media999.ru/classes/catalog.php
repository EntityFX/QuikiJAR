<?
    require_once("control.php");
    
    class Catalog extends TControl
    {
        public function save_edit($link,$flag)
        {
            $fl1=0;
            $fl2="";
            if ($flag) $s="`subsection`"; 
            else {
                $s="`section`";
                $main_check=$_POST["main"];
            }
            $check_query=mysql_query("SELECT COUNT(*) as `ex` FROM $s WHERE `link`='$link'");
            $check_array=mysql_fetch_array($check_query);
            if ($check_array["ex"]!=0) {
                if (TNewString::check_symbols($_POST["title"])) {
                    if (!$flag) {
                        if ($main_check) {
                            mysql_query("UPDATE $s SET `main`=0");
                            $fl1=1; 
                        } else $fl1=0;
                        $fl2=$_POST["invisible"];
                        $tit=$_POST[title];
                        $txt=$_POST[article];
                        $save_query="UPDATE $s SET `title`='$tit', `text`='$txt',`main`=$fl1,`type`=$fl2 WHERE `link`='$link'";
                    } else $save_query="UPDATE $s SET `title`='$_POST[title]', `text`='$_POST[article]' WHERE `link`='$link'";
                    mysql_query($save_query);
                    header("Location: /control/show");
                } else header("Location: /error/4");
            } else header("Location: /error/3"); 
        }
    }
?>