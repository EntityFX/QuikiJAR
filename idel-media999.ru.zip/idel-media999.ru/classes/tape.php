<?
/*
addsite() - добавка сайта, выводит форму и добавляет потом
del_site() - удаляет. нужен id для этого через get-запрос
edit_n() - редактирование. выводит форму, обновляет. нужен id для этого через get-запрос
show_one_site() - показывает массив данных 1 сайта
arr_of_all() - показывает массив данных всех сайтов
*/
	class Tape {

        function addsite($site_title,$site_txt,$site_pct,$site_url) {
			$str_form = "";
			
			if ($site_title != "" and $site_txt !="" and $site_url !="" and $site_pct !=""){
				$users_sec_query=mysql_query("INSERT INTO `sites`SET `siteurl`='$site_url', 
				`title`= '$site_title', `text`= '$site_txt', `sitepct` = '$site_pct' ");
				return "Сайт успешно добавлен!";
			}else{
				return $str_form;
			}	
		
		}
		
		public function show_table($opt) {
			$query = mysql_query("SELECT * FROM `sites`");
			if (mysql_num_rows($query)>0) {
				$tab="<table id=\"bor\">
						<thead>
							<tr><th>Изображение</th><th>Ссылка</th><th></th></tr>
						</thead><tbody>
					";
				if (mysql_num_rows($query)>0) {
					while ($rowt=mysql_fetch_array($query)) {
						$tab=$tab."<tr><td><img src=\"$rowt[sitepct]\" width=\"100\" height=\"100\" alt=\"\" /></td><td>$rowt[sitepct]&nbsp;</td><td><a href=\"/control/tape/del/?id=$rowt[id]\" title=\"Удалить\" class=\"del\">X</a></td></tr>";
					}
				}
				return $tab."</tbody></table>".$this->add_form($opt);
			} return "<p>Пусто</p>".$this->add_form($opt);
		}
		
		function delsite($del_site_id){
			if ($del_site_id != ""){
				$query_for_del = mysql_query("DELETE FROM `sites` WHERE `id` = '$del_site_id'");
				return true;
			}else{
				return false;
			}
		}

		private function add_form($option) {
			$opt="";
			for($i=0;$i<count($option);++$i) $opt=$opt."<option>$option[$i]</option>";
			return "<form action=\"/control/tape/add\" method=\"post\"><div>	  
			Ссылка на файл рисунка в ленте:<br />
			<select name=\"pct\">$opt
			</select><br /> 
			<input type=\"submit\" value=\"Сохранить\" /></div>
			</form>";
		}
		
		public function get_ul($num) {
			$query = mysql_query("SELECT * FROM `sites`");
			$str="<ul>";
			$count=@mysql_num_rows($query);
			if ($count>=0) {
				while($rowt=@mysql_fetch_array($query)) {
					$str=$str."<li><img src=\"$rowt[sitepct]\" alt=\"$rowt[sitepct]\" /></li>\n";
				}
				if ($count<=$num) {
					for($z=1;$z<=$num-$count;++$z) $str=$str."<li><img src=\"/images/empty.png\" alt=\"Пусто\" /></li>\n";
				}
			}
			$str=$str."</ul>";
			return $str;
		}
		
		function edit_n(){
			$site_title = htmlspecialchars($_POST["title"]);
			$site_txt = htmlspecialchars($_POST["txt"]);
			$site_pct = htmlspecialchars($_POST["pct"]);
			$site_url = htmlspecialchars($_POST["adr"]);
			$site_hidden_id = htmlspecialchars($_POST["nums"]);			
			$edit_site_id=$_GET["id"];
		
			$query_site_ed = mysql_query("SELECT * FROM `sites` WHERE `id` = '$edit_site_id'");
			$cnt_sec = mysql_fetch_array($query_site_ed);
			$site_id = $cnt_sec[0];
			$site_url_ed = $cnt_sec[1];
			$site_title_ed = $cnt_sec[2];
			$site_txt_ed = $cnt_sec[3];
			$site_pic_ed = $cnt_sec[4];
			
			
			$edit_form="<form action=\"\" method=\"post\">	  
			Адрес сайта:<br />
			<input type=\"text\" name=\"adr\" size=\"40\" maxlength=\"256\"  value=\"$site_url_ed\" /><br />  
			Заголовок:<br />
			<input type=\"text\" name=\"ttl\" size=\"40\" maxlength=\"256\" value=\"$site_title_ed\"/><br />
			Информация о сайте:<br />
			<textarea name=\"txt\" cols=\"30\" rows=\"5\">$site_txt_ed 
			</textarea>	   <br />  
			Ссылка на файл рисунка:<br />
			<input type=\"text\" name=\"pct\" size=\"40\" maxlength=\"256\" value=\"$site_pic_ed\"/><br /> 
			<input type=\"submit\" value=\"Сохранить\" />
			<input type=\"hidden\" value=\"$site_id\" name=\"nums\">
			</form>";
			
			if ($site_title != "" and $site_txt !="" and $site_url !="" and $site_pct !="" and $site_hidden_id!=""){
				$users_sec_query=mysql_query("UPDATE INTO `sites`SET `siteurl`='$site_url', 
				`title`= '$site_title', `text`= '$site_txt', `sitepct` = '$site_pct' ");
				return "Сайт успешно изменён!";
			}else{
				return $edit_form;
			}
			
		}
		
		function show_one_site(){
			$site_id=$_GET["id"];
			$query_site = mysql_query("SELECT * FROM `sites` WHERE `id` = '$site_id'");
			$cnt_sec = mysql_fetch_array($query_site);
			$site_id = $cnt_sec[0];
			$site_url = $cnt_sec[1];
			$site_title = $cnt_sec[2];
			$site_txt = $cnt_sec[3];
			$site_pic = $cnt_sec[4];
			
			$result_arr["id"] = $site_id;
			$result_arr["url"] = $site_url;
			$result_arr["title"] = $site_title;
			$result_arr["txt"] = $site_txt;
			$result_arr["pic"] = $site_pic;
			
			return 	$result_arr;		
		}
		
		function arr_of_all(){
			$query_site_counts = mysql_query("SELECT COUNT(*) FROM `sites`");
			$counts=mysql_fetch_array($query_site_counts);
			
			$query_sites = mysql_query("SELECT * FROM `sites`");
			
			for($cnt=0;$cnt<=$counts-1;$cnt++){
				$cnt_sec = mysql_fetch_array($query_sites);
				$res_arr["id"] = $cnt_sec[0];
				$res_arr["url"] = $cnt_sec[1];
				$res_arr["title"] = $cnt_sec[2];
				$res_arr["txt"] = $cnt_sec[3];
				$res_arr["pic"] = $cnt_sec[4];
				$res[]=$res_arr;
			}			
			return 	$res;		
		}

    };
?>