<?
	class TLinks {
		private $url;
		private $descr;
		
		public function add_link($url,$descr) {
			$this->url=trim(htmlspecialchars($url));
			$this->url=$this->check_url();
			$this->descr=trim(htmlspecialchars($descr));
			$query="INSERT INTO `links` SET `url`='$this->url', `descr`='$this->descr'";
			mysql_query($query);
		}
		
		public function del_link($id) {
			if (is_numeric($id)) {
				$query="DELETE FROM `links` WHERE `id`=$id";
				mysql_query($query);
			}
		}
		
		public function get_foredit_link($id) {
			if (is_numeric($id)) {
				$query="SELECT `url`,`descr` FROM `links` WHERE `id`=$id";
				$cnt_res=mysql_query($query);
				if (mysql_num_rows($cnt_res)>0) {
					return mysql_fetch_array($cnt_res);
				} else return NULL;
			}			
		}
		
		public function update_link($id,$new_url,$new_descr) {
			if (is_numeric($id)) {
				$this->url=trim(htmlspecialchars($new_url));
				$this->url=$this->check_url();
				$this->descr=trim(htmlspecialchars($new_descr));
				$query="UPDATE `links` SET `url`='$this->url', `descr`='$this->descr' WHERE `id`=$id";
				$cnt_res=mysql_query($query);
			}			
		}
		
		public function get_links_table() {
			$query="SELECT * FROM `links`";
			$cnt_res=mysql_query($query);
			$str="<table id=\"bor\">\n";
			$str=$str."<tr><th>URL</th><th>Описание</th><th></th><th></th></tr>\n";
			$str1="СЃСЃС‹Р»РєСѓ ";
			if (mysql_num_rows($cnt_res)>0) {
				while($cnt_arr=mysql_fetch_array($cnt_res)) {
					$str=$str."<tr><td>$cnt_arr[url]</td><td>$cnt_arr[descr]</td><td><a href=\"/control/editlink/?id=$cnt_arr[id]\">Ред</a></td><td><a href=\"/control/dellink/?id=$cnt_arr[id]\" class=\"del\" onclick=\"return del('$str1$cnt_arr[url]');\">X</a></td></tr>\n";
				}
			}
			$str=$str."</table>";
			return $str;
		}
		
		public function show() {
			$query="SELECT * FROM `links`";
			$cnt_res=mysql_query($query);
			$str="";
			if (mysql_num_rows($cnt_res)>0) {
				while($cnt_arr=mysql_fetch_array($cnt_res)) {
					$str=$str."<dt><a href=\"$cnt_arr[url]\" target=\"_blank\">$cnt_arr[url]</a></dt><dd>$cnt_arr[descr]</dd>\n";
				}
			}
			return "<dl>$str</dl>";
		}
		
		private function check_url() {
			$str=$this->url;
			if ($str!="") {
				if (strpos($str,"http://")===false) $str="http://".$str;
			} else $str="http://www.idel-media.ru";
			return $str;
		}
	}
?>