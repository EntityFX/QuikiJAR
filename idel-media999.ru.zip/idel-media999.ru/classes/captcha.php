<?php
	class Tcaptcha { //капча
	
		var $image; //идентификатор изображения
		var $width; 
        var $height; //ширина, высота
		var $code, $captcha;
        var $symbols_string;
		private $bg_color;
		private $txt_color;		
		private $num_color;
		
		function Tcaptcha($width=150,$height=50) { //конструктор
			$this->width=$width;
			$this->height=$height;
			$code="";
            $this->captcha="";
            $this->symbols_string="ABCDEFGHJKLMNPRSTUWVXYZ123456789";
			return 0;
		}
		
		private function allcolors($num,$discr,$min,$max) {
			$clr=array();
			if ($discr==0) $discr=1;
			for($i=1;$i<=$num;++$i) {
				$div=($max-$min)/$discr;
				$clr[]=imagecolorallocate($this->image,$min+$div*mt_rand(0,$discr),$min+$div*mt_rand(0,$discr),$min+$div*mt_rand(0,$discr));
			}
			return $clr;
		}
		
		function create_captcha($num) {  //создать капчу
			$this->image=imagecreate($this->width,$this->height);
			$d_interval=($this->width-5)/$num;
			$x_offset=5;
			$back_color=imagecolorallocate($this->image,0,0,0);
			//imagecolortransparent($this->image,$back_color);
			$this->num_color=30;
			$this->bg_color=$this->allcolors($this->num_color,10,1,150);
			$font_size=$this->height/1.75;
			$y_offset=$this->height/2.5+2;
			for($i=1;$i<=300;$i++) {
				$line_color=$this->bg_color[mt_rand(1,$this->num_color-1)];
				imagesetpixel($this->image,mt_rand(0,$this->width),mt_rand(0,$this->height),$line_color);
			}
			for($i=1;$i<=12;$i++) {
				$line_color=$this->bg_color[mt_rand(1,$this->num_color-1)];
				imageline($this->image,mt_rand(0,$this->width),mt_rand(0,$this->height),mt_rand(0,$this->width),mt_rand(0,$this->height),$line_color);
			}
            $symbol_to=strlen($this->symbols_string)-1;
			//circles
			$c_x=mt_rand(0,$this->width);
			$c_y=mt_rand(0,$this->height);
			$c_d=mt_rand(5,8);
			$c_t=$this->width / $c_d * 2;
			for ($i=1;$i<=$c_t;$i=$i+$c_d) {
				$c_color=$this->bg_color[mt_rand(0,$this->num_color)];
				imageellipse($this->image, $c_x, $c_y, $i*$c_d, $i*$c_d, $c_color );
			}
			//circles
			$this->num_color=32;
			$this->txt_color=$this->allcolors($this->num_color,10,150,255);
			for($i=1;$i<=$num;$i++) {
				$text_color=$this->txt_color[mt_rand(1,$this->num_color-1)];
				$code=$code.$text_color;
                $l=$this->symbols_string[mt_rand(0,$symbol_to)];
                $this->captcha=$this->captcha.$l;
				//imagettftext($this->image,mt_rand($font_size-4,$font_size+4),mt_rand(-25,25),$x_offset,$y_offset+mt_rand(-2,2),$text_color,"arial.ttf",$l);
				imagestring($this->image,50,$x_offset,$y_offset+mt_rand(-2,2)-10,$l,$text_color);
                $x_offset=$x_offset+$d_interval;
			}
            $this->captcha=$this->captcha;
			$this->get_captcha();
            /*$f=fopen("c:/1.txt","w");
            fputs($f,$this->captcha);*/
			session_start();
			$_SESSION['cap_code']=$this->get_code(); 
            return 1;
		}
        
		function get_code() {
            return $this->captcha;
        }
        
		function get_captcha() {
            header('Expires: Sut, 1 Jun 2000 05:00:00 GMT'); 
            header('Cache-Control: no-store, no-cache, must-revalidate'); 
            header('Cache-Control: post-check=0, pre-check=0', FALSE); 
            header('Pragma: no-cache');
			Header("Content-type: image/png");
            Imagepng($this->image);
			if (Imagepng($this->image)==0) {
				Header("Content-type: image/gif");
				if (Imagegif($this->image)==0) {
					Header("Content-type: image/jpeg");
					Imagejpeg($this->image);
				}
			}
		}
        
        function check_captcha($str) {
            session_start();
            if (isset($_SESSION['cap_code'])) {
                if ($_SESSION['cap_code']==strtoupper($str)) $res=true; else $res=false;    
            } else $res=false;
            //session_destroy();
            return $res;
        }
	};
?>