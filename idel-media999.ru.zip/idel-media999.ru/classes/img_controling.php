<?
	require_once("control.php");
	class TImg_ctrl {
		public $list;
		private $tpl;
		private $arr_strs;
		private $arr_list;
		private $cur;
		public $picture_count;
		
		function __construct(&$tpl){
			$cfg=new TConf;
			$this->picture_count=$cfg->get_images();
			$this->cur=getcwd();
			$this->tpl=$tpl;
			$this->sort_files();
		}
		
		function dir_files() {
			$dir = @opendir($this->cur."/images/content/");
			while ( $imgfile = @readdir ($dir))
			{
				if (( $imgfile != ".") && ($imgfile != "..") && (@strtolower($imgfile) != "thumbs.db"))
				{
					$path="$this->cur/images/content/$imgfile";
					$imgfilestr[@filemtime($path)]=$path;
				}
			}
			closedir ($dir);
			return $imgfilestr;
		}
		
		private function sort_files() {
			$dir=$this->cur."/images/content"; 
			$list = scandir( $dir );
			foreach( $list as $name ) 
			{ 
				$time[$name] =  filemtime( $dir."/".$name );    
			} 
			arsort( $time );
			
			$arr_size=sizeof($time);
			$pic_cnt=$this->picture_count;
			$this->arr_strs=ceil(($arr_size-2)/$pic_cnt); //Р·РґРµСЃСЊ РР—РњР•РќРРўР¬ С†РёС„СЂСѓ 3 РЅР° С†РёС„СЂСѓ 2 РїРµСЂРµРґ Р·Р°Р»РёРІРєРѕР№ РЅР° СЃРµСЂРІРµСЂ!!!
			$this->arr_list=$_GET["page"];
			$arr_counted=0;
			$arr_n=($this->arr_list - 1)*$pic_cnt+1;
			$arr_k=$this->arr_list*$pic_cnt;
			$cnt = 0;
			$str1="изображение ";
			foreach( $time as $key => $value )  
			{ 
				if ( $key != "." and $key != ".." and (@strtolower($key) != "thumbs.db") )
				{
					if (getimagesize($this->cur."/images/content/$key") != false){
						$arr_counted++;
						if ($arr_counted >= $arr_n  and $arr_counted <= $arr_k) {
							list($width, $height, $type, $attr) = getimagesize($this->cur."/images/content/$key");
							$valuesrc=htmlspecialchars("/images/content/$key");
							$imgfilestr =$imgfilestr."<tr>
							<td><a href=\"/images/content/$key\">
							<img src=\"/images/small/$key\" alt=\"\" /></a></td>
							<td>".date("d.m.Y H:i:s", $value)."  </td>
							<td><form action=\"\"><div>
							<input type=\"text\" name=\"insert_code\" size=\"20\" maxlength=\"256\" 
							value=\"$valuesrc\" /></div>
							</form></td>
							<td><form  method=\"post\" action=\"/control/images\"><div><input type=\"hidden\" 
							value=\"$value\" name=\"rename\" /><input type=\"text\" value=\"\" name=\"newname\" />
							<input type=\"submit\" name=\"submit\" value=\"Переименовать\" />
							</div></form></td>
							<td><a href=\"/control/imgdel/?del=".$value."\" class=\"del\" onclick=\"return del('$str1$key');\">X</a></td></tr>\n";
						} 
					}
				}
			}
			if ($arr_counted != 0){
				$imgfilestr=$this->pages()."<table>\n<tr><th>Изображение</th><th>Дата</th><th>URL адрес</th><th>Переименовать</th></tr>".$imgfilestr;
				$imgfilestr=$imgfilestr."</table>".$this->pages();
				$this->tpl->set_var_value("TPLTEXT",$imgfilestr);
			}else
			$this->tpl->set_var_value("TPLTEXT","Изображения ещё не загружены");
		}
		
		
		private function pages() {
			for($cnt=1;$cnt<=$this->arr_strs;$cnt++)
			{
				if ($cnt != $this->arr_list) 
				$imgfilestr= $imgfilestr." <a href=\"/control/images/?page=$cnt\">$cnt</a>";
				else
				$imgfilestr= $imgfilestr." <b class=\"sel\">$cnt</b>";
			}
			return $imgfilestr;
		}
		
		function del_file(){
			$deleting_file = $_GET["del"];
			$dir=$this->cur."/images/content";
			if ($deleting_file !=""){
				$imgs_for_del = $this->dir_files();
				@unlink($imgs_for_del[$deleting_file]);	
			}
		}
		
		function rename_file(){
			$renaming_file_id = $_POST["rename"];
			$renamed_file_name = $this->trans($_POST["newname"]);
			if ($renaming_file_id !=""){
				$imgs_for_re = $this->dir_files();
				$file_name_cycle=$imgs_for_re[$renaming_file_id];
				$file_ext=substr($file_name_cycle, strlen($file_name_cycle)-4); //Р·РґРµСЃСЊ РїСЂРѕРІРµСЂРёС‚СЊ С†РёС„СЂСѓ 4 РїСЂРё Р·Р°РіСЂСѓР·РєРµ РЅР° СЃРµСЂРІРµСЂ!!!
				$new_file_name="$renamed_file_name$file_ext";
				while (file_exists($new_file_name)){
					$file_oldname=substr($new_file_name,0, strlen($new_file_name)-4);
					$file_ext2=substr($new_file_name, strlen($new_file_name)-4);
					$new_file_name=$file_oldname."_1".$file_ext2;
				} 				
				
				rename($file_name_cycle,$new_file_name);
				header("Location: /control/images/?page=1");
			}
		}
		
		function check_ex_file($file_name){
			$file_name_cycle=$file_name;
			while (file_exists($this->cur."/images/content/$file_name_cycle")){
				$file_oldname=substr($file_name_cycle,0, strlen($file_name_cycle)-4);
				$file_ext=substr($file_name_cycle, strlen($file_name_cycle)-4);
				$file_name_cycle=$file_oldname."_1".$file_ext;
			} 
			copy($this->cur."/images/tmp/$file_name",$this->cur."/images/content/$file_name_cycle");
		}
		
		function load() {
			$path_name=$this->cur."/images/tmp/".basename($this->trans($_FILES['filename']['name']));
			if(copy($_FILES['filename']['tmp_name'],$path_name))
			{
				$lods_file_name=basename($this->trans($_FILES['filename']['name']));
				$type=getimagesize($path_name);
				$t=$type[2];
				if ($t==1 || $t==2 || $t==3) {
					$small_path=$this->cur."/images/small/".$this->trans($_FILES['filename']['name']);
					$this->make_small($path_name,$small_path,80);
					$this->check_ex_file($lods_file_name);
					unlink($this->cur."/images/tmp/".basename($this->trans($_FILES['filename']['name'])));
				}
				else {
					unlink($this->cur."/images/tmp/".basename($this->trans($_FILES['filename']['name'])));
					return -1;
				}
				return 1;
			}
			else {
				return 0;
			}
		}

		
		public function make_small($from,$to,$qua) {
			$qualif=80;
			$info=getimagesize($from);
			$fr_width=$info[0];
			$fr_height=$info[1];
			if($fr_width>=$fr_height) {
				$del=$fr_width/$qualif;
				$new_height=$fr_height/$del;
				$this->resize_copy($from,$to,$qualif,$new_height,$qua);
			} else {
				$del=$fr_height/$qualif;
				$new_width=round($fr_width/$del);
				$this->resize_copy($from,$to,$new_width,$qualif,$qua);			
			};
		}
		
		private function resize_copy($from,$to,$w,$h,$qua) {
			$arr=getimagesize($from);
			$type=$arr[2];
			switch ($type) {
				case 1: $img=imagecreatefromgif($from); break; //GIF
				case 2: $img=imagecreatefromjpeg($from); break; //Jpeg
				case 3: $img=imagecreatefrompng($from); break; //PNG
			}
			$img_pro=imagecreatetruecolor($w,$h);
			imagecopyresampled($img_pro,$img,0,0,0,0,$w,$h,imagesx($img),imagesy($img));
			imagejpeg($img_pro,$to,$qua);
			imagedestroy($img);
			imagedestroy($img_pro);
		}
		
		public static function get_src() {
			$dir=getcwd()."/images/content"; 
			$list = scandir($dir);
			foreach( $list as $name ) if ($name!="." && $name!="..") $opt[]="/images/content/".$name;
			return $opt;
		}
		
		function trans($st) {
			$lit = array(
'А' => 'A',
                'Б' => 'B',
                'В' => 'V',
                'Г' => 'G',
                'Д' => 'D',
                'Е' => 'E',
                'Ё' => 'YO',
                'Ж' => 'ZH',
                'З' => 'Z',
                'И' => 'I',
                'Й' => 'J',
                'К' => 'K',
                'Л' => 'L',
                'М' => 'M',
                'М' => 'N',
                'О' => 'O',
                'П' => 'P',
                'Р' => 'R',
                'С' => 'S',
                'Т' => 'T',
                'У' => 'U',
                'Ф' => 'F',
                'Х' => 'H',
                'Ц' => 'C',
                'Ч' => 'CH',
                'Ш' => 'SH',
                'Щ' => 'CSH',
                'Ь' => '',
                'Ы' => 'Y',
                'Ъ' => '',
                'Э' => 'E',
                'Ю' => 'YU',
                'Я' => 'YA',
                'а' => 'a',
                'б' => 'b',
                'в' => 'v',
                'г' => 'g',
                'д' => 'd',
                'е' => 'e',
                'ё' => 'yo',
                'ж' => 'zh',
                'з' => 'z',
                'и' => 'i',
                'й' => 'j',
                'к' => 'k',
                'л' => 'l',
                'м' => 'm',
                'н' => 'n',
                'о' => 'o',
                'п' => 'p',
                'р' => 'r',
                'с' => 's',
                'т' => 't',
                'у' => 'u',
                'ф' => 'f',
                'х' => 'h',
                'ц' => 'c',
                'ч' => 'ch',
                'ш' => 'sh',
                'щ' => 'csh',
                'ь' => '',
                'ы' => 'y',
                'ъ' => '',
                'э' => 'e',
                'ю' => 'yu',
                'я' => 'ya',
			
			"!" => "",
			"в„–" => "",
			";" => "",
			":" => "",
			"@" => "",
			"#" => "",
			"$" => "",
			"%" => "",
			"&" => "",
			"?" => "",
			"~" => "",
			"`" => "",
			"'" => "",
			"\"" => "",
			" " => "_",
				);
			return $st = strtr($st, $lit);
		}
	}
?>