<?
	class TNewString {
		public function encodestring($string)
		{
			$table = array(
                'А' => 'A',
                'Б' => 'B',
                'В' => 'V',
                'Г' => 'G',
                'Д' => 'D',
                'Е' => 'E',
                'Ё' => 'YO',
                'Ж' => 'ZH',
                'З' => 'Z',
                'И' => 'I',
                'Й' => 'J',
                'К' => 'K',
                'Л' => 'L',
                'М' => 'M',
                'Н' => 'N',
                'О' => 'O',
                'П' => 'P',
                'Р' => 'R',
                'С' => 'S',
                'Т' => 'T',
                'У' => 'U',
                'Ф' => 'F',
                'Х' => 'H',
                'Ц' => 'C',
                'Ч' => 'CH',
                'Ш' => 'SH',
                'Щ' => 'CSH',
                'Ь' => '',
                'Ы' => 'Y',
                'Ъ' => '',
                'Э' => 'E',
                'Ю' => 'YU',
                'Я' => 'YA',
                'а' => 'a',
                'б' => 'b',
                'в' => 'v',
                'г' => 'g',
                'д' => 'd',
                'е' => 'e',
                'ё' => 'yo',
                'ж' => 'zh',
                'з' => 'z',
                'и' => 'i',
                'й' => 'j',
                'к' => 'k',
                'л' => 'l',
                'м' => 'm',
                'н' => 'n',
                'о' => 'o',
                'п' => 'p',
                'р' => 'r',
                'с' => 's',
                'т' => 't',
                'у' => 'u',
                'ф' => 'f',
                'х' => 'h',
                'ц' => 'c',
                'ч' => 'ch',
                'ш' => 'sh',
                'щ' => 'csh',
                'ь' => '',
                'ы' => 'y',
                'ъ' => '',
                'э' => 'e',
                'ю' => 'yu',
                'я' => 'ya',
				' ' => '_',
				'&' => "_n_",
				'/' => "_sl_",
				'<' => "_lt_",
				'>' => "_gt_",				
			);

			$output = str_replace(
			array_keys($table),
			array_values($table),$string
			);
			return $output;
		}	
		
		public function make_translit($value) {
			$a[" "]="_";
			$a["а"]="a";
			$a["б"]="b";
			$a["в"]="v";
			$a["г"]="g";
			$a["д"]="d";
			$a["е"]="e";
			$a["ё"]="yo";
			$a["ж"]="zh";
			$a["з"]="z";
			$a["и"]="i";
			$a["й"]="y";
			$a["к"]="k";
			$a["л"]="l";
			$a["м"]="m";
			$a["н"]="n";
			$a["о"]="o"; 
			$a["п"]="p";
			$a["р"]="r";
			$a["с"]="s";
			$a["т"]="t";
			$a["у"]="u";
			$a["ф"]="f";
			$a["х"]="h";
			$a["ц"]="tz";
			$a["ч"]="ch";
			$a["ш"]="sh";
			$a["щ"]="sch";
			$a["ъ"]="''";
			$a["ы"]="y";
			$a["ь"]="_";
			$a["э"]="e";
			$a["ю"]="yu"; 
			$a["я"]="ya";
			$a["&"]="_n_";
			$a["<"]="lq";
			$a[">"]="rq";
			$value=iconv("UTF-8", "WINDOWS-1251",$value);
			$value=trim($this->tolower($value));
			$res="";
			for($i=0;$i<strlen($value);$i++) {
				if ($a[$value[$i]]!="") $res=$res.$a[$value[$i]]; else $res=$res.$value[$i];
			}
			return $res;
		}
		
		private function tolower($content) { 
			$content = strtr($content,"АБВГДЕЁЖЗИЙКЛМНОРПСТУФХЦЧШЩЪЬЫЭЮЯ","абвгдеёжзийклмнорпстуфхцчшщъьыэюя"); 
            return strtolower($content);
		}
		
		static public function check_symbols($string) {
			$string=trim($string);
			$string=iconv("UTF-8", "cp1251",$string);
			//die($string);
			//$reg=iconv("UTF-8", "cp1251","[^a-zA-Zа-яА-Я0-9\(\)\.\-\_\ \ё\Ё]+");
			//die(eregi("[^a-zA-Zа-яА-Я0-9\(\)\.\-\_\ \ё\Ё]",$string)." ");
			$rep=array("&","<",">",";");
			//die(str_replace($rep,"",$string));
			//if (ereg($reg,$string) || $string=="") return false; else return true;
			return true;
		}
		
		static public function numbers($before,$from,$to,$after) {
			$str="";
			for($i=$from;$i<=$to;++$i) $str=$str.$before.$i.$after."\n";
			return $str;
		}
	}
?>