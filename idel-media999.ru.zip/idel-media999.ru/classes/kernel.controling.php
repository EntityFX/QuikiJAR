<? /* Панель администрирования: Обработчик
    Обязательноый файл, используется в kernel.php */
    $tpl->set_var_value("LOGO","<h2>Редактирование разделов</h2>");
    $tpl->set_var_value("USEROK",$auth->get_user());
    $messenger=new TMessages();
    $tpl->set_var_value("TOT",$messenger->count_);
    $contr = new TControl($tpl,$this);
    $links=new Tlinks;
    $logo=$_GET["sec"];
    $link="/".$logo;
    $tpl->set_var_value("MENU",$tpl->get_from_file("templates/menu_control.tpl"));
    if (!$tpl->get_template("templates/control.tpl")) echo "Не удалось загрузить шаблон";    
    switch ($this->url_array[1]) {
        case "show":
            $this->text=$contr->make_tree();
            if (!$tpl->get_template("templates/control_show.tpl")) echo "Не удалось загрузить шаблон";
            $tpl->set_var_value("LOGO","<h2>Редактирование разделов</h2>");
            $section_list=$contr->get_section_list();
            $tpl->set_var_value("OPTION",$section_list);
            $tpl->set_var_value("LIST",$section_list);
            break;
        case "edit":
            if (isset($_GET["sec"]))
            {
                if (!$tpl->get_template("templates/control_edit.tpl")) echo "Не удалось загрузить шаблон";
                if (isset($_GET["subsec"]))
                {
                    $link=array("parentLink" => $_GET['sec'], "childrenLink" => $_GET['subsec']);
                    $text_ext=$contr->get_for_edit($tpl,$link,true);
                    $main_check="";
                }
                else
                {
                    $text_ext=$contr->get_for_edit($tpl,$logo,false);
                    if ($contr->is_main($_GET["sec"])) $checked="checked"; else $checked="";
                    if ($contr->is_invisible($_GET["sec"])) $checked1="checked"; else $checked1="";                    
                    $main_check="<input type=\"checkbox\" name=\"main\" $checked/><label> Выводить на главной</label><br>";
                    $inv_check="<input type=\"checkbox\" name=\"invisible\" $checked1/><label> Скрытый</label><br>";
                }
                include("classes/ckeditor/ckeditor.php") ;
                $CKEditor = new CKEditor();
                $CKEditor->basePath = '/classes/ckeditor/';
                $CKEditor->returnOutput = true;
                $CKEditor->config['width'] = 770;
                $CKEditor->config['height'] = 400;
                $config['skin'] = 'office2003';
                $code = $CKEditor->editor("article", $text_ext,$config);
                $tpl->set_var_value("EDITOR",$code);
                $tpl->set_var_value("MAIN",$main_check);
                $tpl->set_var_value("INVISIBLE",$inv_check);
                $tpl->set_var_value("LOGO","<h2>Редактирование раздела: $editing_array[title]</h2>");
                if (is_array($link))
                {
                    $get="?sec=$link[parentLink]&subsec=$link[childrenLink]";
                }
                else 
                {
                    $get="?sec=$logo";
                }
                $tpl->set_var_value("GET","$get");
            } else header("Location: /control/show");
            break;
        case "save":
            if (isset($_GET["subsec"]))
            {
                $link=array("parentLink" => $_GET['sec'], "childrenLink" => $_GET['subsec']); 
                $contr->save_edit($link,true);
            }
            else
            {
                $contr->save_edit($logo,false); 
            }
            break;
        case "del":
            if (isset($_GET["subsec"]))
            {
                $link=array("parentLink" => $_GET['sec'], "childrenLink" => $_GET['subsec']);
                $contr->del_edit($link,true);
            }
            else
            {
                $contr->del_edit($logo,false); 
            }
            break;
        case "addsec":
            try
            {
                $contr->add_sec();
            }
            catch (Exception $exc)
            {
                header("Location: /error/4");    
            }
            break;
        case "addsubsec":
            try
            {
                $contr->add_subsection();
            }
            catch (Exception $exc)
            {
                header("Location: /error/4/");     
            }
            break;
        case "movedown":
            if (isset($_GET["sec"]))
            {
                if (isset($_GET["subsec"]))
                {
                    $link=array("parentLink" => $_GET['sec'], "childrenLink" => $_GET['subsec']); 
                    $contr->move_up($link,false);
                }
                else
                {
                    $contr->move_up($logo,true); 
                }
            }
            break;
        case "moveup":
            if (isset($_GET["sec"])) {
                if (isset($_GET["subsec"])) {
                    $link=array("parentLink" => $_GET['sec'], "childrenLink" => $_GET['subsec']); 
                    $contr->move_down($link,false);
                } else {
                    $contr->move_down($logo,true); 
                }
            }
            break;
        case "links":
            if (!$tpl->get_template("templates/control_links.tpl")) echo "Не удалось загрузить шаблон";
            $tpl->set_var_value("LOGO","<h2>Управление ссылками</h2>");
            $tpl->set_var_value("LINKS_TABLE",$links->get_links_table());
            break;
        case "addlink":
            $links->add_link($_POST["url"],$_POST["article"]);
            header("Location: /control/links");
            break;
        case "dellink":
            if (isset($_GET["id"])) $links->del_link($_GET["id"]);
            header("Location: /control/links");
            break;    
        case "editlink":
            if (!$tpl->get_template("templates/control_links_edit.tpl")) echo "Не удалось загрузить шаблон";
            if (isset($_GET["id"]) && ($links_foredit_arr=$links->get_foredit_link($_GET["id"]))!=NULL ) {
                $tpl->set_var_value("URL",$links_foredit_arr["url"]);
                $tpl->set_var_value("DESCR",$links_foredit_arr["descr"]);
                $tpl->set_var_value("GET",$_GET["id"]);
            } else header("Location: /control/links");
            break;
        case "updatelink":
            if (isset($_GET["id"])) $links->update_link($_GET["id"],$_POST["url"],$_POST["article"]);
            header("Location: /control/links");
            break;
        case "images": //оброботко озоброжоной
            if (!$tpl->get_template("templates/img_load.tpl")) echo "Не удалось загрузить шаблон";
            $imgctrllng = new TImg_ctrl($tpl);
            $imgctrllng->rename_file();
            $tpl->set_var_value("LOGO","<h2>Управление изображениями</h2>");
            break;
        case "imgdel":
            $imgctrllng = new TImg_ctrl($tpl);
            $imgctrllng->del_file();
            header("Location: /control/images/?page=1");
            break;
        case "imgload":
            $imgctrllng = new TImg_ctrl($tpl);
            switch ($imgctrllng->load()) {
                case 0: header("Location: /error/6/");
                    break;
                case -1: header("Location: /error/8/");
                    break;
                case 1: header("Location: /control/images/?page=1");
            }
            break;
        case "messages":
            if (!$tpl->get_template("templates/control_messages_show.tpl")) echo "Не удалось загрузить шаблон";
            if (isset($_GET["id"])) $id=$_GET["id"]; else $id=1;
                $messenger=new TMessages($id);
                $tpl->set_var_value("MESSAGES",$messenger->getmsg());
                $tpl->set_var_value("LINKS1",$messenger->links_line());
            break;
        case "msgdel":
            $messenger=new TMessages();
            if (isset($_GET["id"])) $id=$_GET["id"]; else $id=1;
                $messenger->delete_link($id);
            header("Location: /control/messages");
            break;            
        case "news":
            if (!$tpl->get_template("templates/control_news.tpl")) echo "Не удалось загрузить шаблон";
            $news = new TNews();
            switch ($this->url_array[2]) {
                case "add":
                    $res_n = $news->add_news();
                    $tpl->set_var_value("NEWST",$res_n);
                    $tpl->set_var_value("LOGO","<h2>Удаление новости</h2>");
                    break;
                case "edit":
                    $res_n = $news->edit_n();
                    $tpl->set_var_value("NEWST",$res_n);
                    $tpl->set_var_value("LOGO","<h2>Редактирование новости</h2>");
                    break;
                case "del":
                    $res_n = $news->del_news();
                    $tpl->set_var_value("NEWST",$res_n);
                    $tpl->set_var_value("LOGO","<h2>Удаление новости</h2>");
                    break;

                default:
                    $res_n = "<a href=\"/control/news/add\">Создать новость.</a><br /> <a href=\"/control/news/\">Просмотреть все новости.</a><br /><br />";
                    $tpl->set_var_value("NEWST",$res_n.$news->show_some_n_a());
                    $tpl->set_var_value("LOGO","<h2>Управление новостями</h2>");
            }
            break;
        case "conf":
            $contr->show_links($_POST["shlinks"]);
            $contr->show_news($_POST["shnews"]);    
            $contr->show_messages($_POST["shmsg"]);
            $contr->show_response($_POST["shresp"]); 
            $contr->show_tape($_POST["shtape"]);   
            $contr->set_messges($_POST["nummsg"]);        
            $contr->set_images($_POST["numimg"]);            
            header("Location: /control");
            break;
        case "questions":
            $question=new TQuestion;
            if (!$tpl->get_template("templates/control_qss.tpl")) echo "Не удалось загрузить шаблон";
            switch ($this->url_array[2]) {
                case "add":
                    if (!$tpl->get_template("templates/control_qss_add.tpl")) echo "Не удалось загрузить шаблон";
                    $tpl->set_var_value("QUESTIONS",$question->make());
                    $tpl->set_var_value("LOGO","<h2>Добавить опрос</h2>");    
                    break;
                case "save":
                    $question->save();
                    header("Location: /control/questions");
                    break;
                case "del":
                    $question->delete($_GET["id"]);
                    header("Location: /control/questions");
                    break;
                case "edit":
                    if (!$tpl->get_template("templates/control_qss_add.tpl")) echo "Не удалось загрузить шаблон";
                    $tpl->set_var_value("QUESTIONS",$question->edit($_GET["id"]));
                    $tpl->set_var_value("FORM",$question->add_new_q_a());
                    $tpl->set_var_value("LOGO","<h2>Редактировать опрос</h2>");    
                    break;
                case "update":
                    $question->update();
                    header("Location: /control/questions");
                    break;
                case "null":
                    $question->null_one($_GET["id"]);
                    header("Location: /control/questions");
                    break;
                default:
                    $tpl->set_var_value("QUESTIONS",$question->show_all_q_a());
                    $frm=$question->add_new_q_a();
                    $tpl->set_var_value("LOGO","<h2>Настройка опросов</h2>");    
            }
            $tpl->set_var_value("FORM",$frm);
            break;
        case "tape":
            if (!$tpl->get_template("templates/control_tape.tpl")) echo "Не удалось загрузить шаблон";
            $tpl->set_var_value("LOGO","<h2>Редактирование ленты</h2>");    
            $tape=new Tape();
            $tpl->set_var_value("TAPE_TABLE",$tape->show_table(TImg_ctrl::get_src()));
            switch ($this->url_array[2]) {
                case "add": 
                    $tape->addsite(" "," ",$_POST["pct"]," ");
                    header("Location: /control/tape");
                    break;
                case "del":
                    $tape->delsite($_GET["id"]);
                    header("Location: /control/tape");
                    break;
            }
            break;
        case "catalog":
            $catalogue=new Cat_ctrl("/control/catalog/");
            if (!$tpl->get_template("templates/control_news.tpl")) echo "Не удалось загрузить шаблон";
            $tpl->set_var_value("LOGO","<h2>Редактирование каталогов</h2>");
            $tpl->set_var_value("NEWST",$catalogue->editTree($_GET["id"],$_GET["ed"]));
            break;
        case "answers":
            $anque=new AnswerQuestion("/control/answers/");
            if (!$tpl->get_template("templates/control_news.tpl")) echo "Не удалось загрузить шаблон";
            $tpl->set_var_value("LOGO","<h2>Вопрос-Ответ</h2>");
            if ($anque->admQuests($_GET["e"],$_GET["id"])!="")
            {
                $tpl->set_var_value("NEWST",$anque->admQuests($_GET["e"],$_GET["id"]));
            }
            else
            {
                $tpl->set_var_value("NEWST","Вопросов нет");                
            }
            break;    
        default : 
            $tpl->set_var_value("LOGO","<h2>Раздел администрирования</h2>");
            $tpl->set_var_value("checked1",$contr->on_links());
            $tpl->set_var_value("checked2",$contr->on_news());    
            $tpl->set_var_value("checked4",$contr->on_messages());
            $tpl->set_var_value("checked3",$contr->on_response());
            $tpl->set_var_value("checked5",$contr->on_tape());
            $tpl->set_var_value("TOTMSG",$contr->get_messges());
            $tpl->set_var_value("TOTIMG",$contr->get_images());            
    }
?>