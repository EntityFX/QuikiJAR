<?php
    class Cat_ctrl
    { 
        /*help
        внешние функции:
        makeTree()-показывает меню для обычного пользователя
        editTree($_GET["id"],$_GET["ed"]) - показывает меню для админа (добавление, редактирование, удаление перемещение)
        
        
        
        База:
        
        
    CREATE TABLE IF NOT EXISTS `catalog` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) default NULL,
  `pos` int(11) NOT NULL,
  `levelstr` int(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=105 ; 
        */
        
        private $act_str;
                
        public function __construct($address)
        {
            $this->act_str=$address;
        }
        
        function showItems($level)
        {
            $res_str = "";
            $check_query = mysql_query("SELECT * FROM `catalog` WHERE `levelstr`='$level'");
            while($item_str = @mysql_fetch_array($check_query))
            {
                $res_str = $res_str."<br />".$item_str["title"];
            }
            return $res_str;
        }
        
        function addItem($title,$url,$sub_id)
        {
            $add_str = "<form method=\"post\" action=\"$this->act_str\">
            <div>
            Заголовок
            <input type=\"text\" name = \"title\" value = \"\" maxlength = \"40\" /><br /> 
            Ссылка" 
            .$this->makeSelectLink()
            ."<br />
            
            <select name=\"lev\">
            <option value=\"0\">Уровень 0</option>
            <option value=\"1\">Уровень 1</option>
            <option value=\"2\">Уровень 2</option>
            </select> <br />
            <input type=\"submit\" value = \"Создать\" />
            </div>
            </form>";
            //$add_query = mysql_query("SELECT * FROM `catalog` WHERE `type`='2'"); 
            
            if($title!="")
            {
                $pos_curr = $this->getNewPos();
                $title1=htmlspecialchars($title);
                if ($url=="") $url_s=""; else $url_s=$this->returnMeLink($url); 
                $add_query = mysql_query("INSERT INTO `catalog` VALUES(0,'$title1','$url_s','$pos_curr','$sub_id')"); 
                return "Пункт меню добавлен<br />".$add_str;
                
            }      
            else
            {
                return $add_str;             
                //$err_str = "Название раздела не введено"; 
                //$add_str = $add_str."<br /><br />".$err_str;
            }
        }
        
        private function getNewPos()
        {
            $check_query = mysql_query("SELECT MAX(`pos`) FROM `catalog`");
            $pos_str = mysql_fetch_array($check_query);
            $max = $pos_str[0] + 1;
            return $max;
        }
        
        public function makeTree()
        {
            $res_str = "";
            $check_query = mysql_query("SELECT * FROM `catalog` ORDER BY `pos` ASC");
            $flaag = false;   //проверяет находимся ли в списке <ul></ul>
            $flag_1 = false; //проверяет находимся ли после уровня 1, чтоб если что закрыть блок на всякий случай непредвиденных обстоятельств, вызывающих неприятные чувства в виду некрасивого отображения списка каталогов в пользовательской части интерфейса программы, который, как известно, должен выглядеть безупречно, ибо это и есть основная цель создания сайта. Вот
            $flag_0 = false; //проверяет находимся ли после уровня 0, а то если бы этого флага не было, то получилось вложение двух дивов один в другой :'( а так - поставим флаг и благодаря ему тег будет закрываться и все будут рады, и будет красиво, и Бог улыбнется. и зарплата будет, и счастье, ну в общем ясно.
            while($item_str = @mysql_fetch_array($check_query))
            {
                switch ((int)$item_str["levelstr"])
                {
                    case 0:
                        if ($flaag)
                        {
                            //$item_b = "</ul>\n</div>\n<div class=\"block\">\n<div class=\"htwo\"><h2>";
                            //$item_e = "</h2></div>\n";
                            $ul_close = "</ul>\n";
                        }
                        else
                        {
                            //$item_b = "<div class=\"block\">\n<div class=\"htwo\"><h2>";
                            //$item_e = "</h2></div>\n";
                            $ul_close = "";
                        }
                        $flaag = false;
                        
                        if ($flag_1)
                        {
                            $item_b = "</div>\n<div class=\"block\">\n<div class=\"htwo\"><h2>";
                            $item_e = "</h2></div>\n";
                            $flag_1 = false;
                        }
                        if ($flag_0)
                        {
                            $item_b = "$ul_close </div>\n<div class=\"block\">\n<div class=\"htwo\"><h2>";
                            $item_e = "</h2></div>\n";
                            //$flag_0 = false;                            
                        }
                        else
                        {
                            $item_b = "$ul_close <div class=\"block\">\n<div class=\"htwo\"><h2>";
                            $item_e = "</h2></div>\n";
                            $flag_0 = true; 
                        }
                        
                        //echo "<br />0";
                        break;
                    case 1:
                        if ($flaag)
                        {
                            $item_b = "</ul>\n<strong>";
                            $item_e = "</strong>\n";
                        }
                        else
                        {
                            $item_b = "<strong>";
                            $item_e = "</strong>\n";
                        }
                        $flaag = false; 
                        $flag_1 = true;
                        //echo "<br />1";
                        break;
                    case 2: 
                        if (!$flaag)
                        {
                            $item_b = "<ul>\n<li>";
                            $item_e = "</li>\n";
                            $flaag = true;
                        }
                        else
                        {
                            $item_b = "<li>";
                            $item_e = "</li>\n";
                        } 
                        //echo "<br />2";
                        break;
                    default: break;
                }
                if($item_str["url"]!="") //здесь обработаешь переменные чтоб в css редактировать
                {
                    if ((int)$item_str["levelstr"]!=0)
                    {
                        $link_str_b = "<a href=\"".$item_str["url"]."\">  ";
                        $link_str_e = "</a>";
                    } 
                }
                else
                {
                    $link_str_b = "";
                    $link_str_e = "";                      
                }
                //здесь вставишь переменные в нужное место 
                $res_str.= $item_b.$link_str_b.$item_str["title"].$link_str_e.$item_e;
            }
            
            if (!$flaag)
            {
                $res_str = $res_str."</div>";
            }
            else
            {
                $res_str = $res_str."</ul></div>";
            }
            return $res_str;             
         }
         
         private function normalize()
         {
            $ex_q=mysql_query("SELECT COUNT(*) as `first` FROM `catalog` WHERE `pos`=0");
            $num=mysql_fetch_array($ex_q);
            if ($num["first"]==1)
            { 
                $q=mysql_query("UPDATE `catalog` SET `levelstr`=0 WHERE `pos`=0");
            }
         }
         
         public function editTree($id,$ed)
         {
            //$this->normalize();
             if ($_POST["title"]!="" && $ed=="") $this->addItem($_POST["title"],$_POST["url"],$_POST["lev"]); 
             if($id=="" && $ed=="")//просто показывается меню
             {
                $res_str = "";
                $check_query = mysql_query("SELECT * FROM `catalog` ORDER BY `pos` ASC");
                $d_str="";
                $p_str="";
                while($item_str = @mysql_fetch_array($check_query))
                {
                    switch ($item_str["levelstr"])
                    {
                        case 0:
                            $d_str="<strong>";
                            $p_str="</strong>"; 
                            break;
                        case 1:
                            $d_str="&nbsp;";
                            $p_str="";
                            break;
                        case 2:
                            $d_str="&nbsp;&nbsp;&nbsp;";
                            $p_str=""; 
                            break;
                        default:
                            $d_str=$p_str=""; 
                            break;                                           
                    }
                   
                    if($item_str["url"]!="") //здесь обработаешь переменные чтоб в css редактировать
                    {
                        if ($item_str["levelstr"]!=0)
                        {
                            $link_str_b = "<a href=\"".$item_str["url"]."\">  ";
                            $link_str_e = "</a>";
                        } 
                    }
                    else
                    {
                        $link_str_b = "";
                        $link_str_e = "";                      
                    }
                    //здесь вставишь переменные в нужное место 
                    $id_o = $item_str["id"];
                    $res_str.="<tr>".
                        "<td>".$d_str.$link_str_b.$item_str["title"].$link_str_e.$p_str.
                        "</td><td><a href=\"$this->act_str?id=$id_o"."&amp;ed=1\">Ред</a>
                        <a href=\"?id=$id_o"."&amp;ed=2\" class=\"del\">X</a></td>
                        <td><a href=\"$this->act_str?id=$id_o"."&amp;ed=3\">◄</a>
                        <a href=\"$this->act_str?id=$id_o"."&amp;ed=4\">►</a>
                        <a href=\"$this->act_str?id=$id_o"."&amp;ed=5\">▲</a>
                        <a href=\"$this->act_str?id=$id_o"."&amp;ed=6\">▼</a></td>
                    </tr>" ;
                }
                $table.="
                <table>
                    <thead>
                        <tr><th>Название</th><th>Управление</th><th>Уровень</th></tr>
                    </thead>
                    <tbody>";

                $res_str=$table.$res_str."</tbody></table>
                Добавить пункт:<br />".$this->addItem("","","");                
                return $res_str;
                
            } 
            else//операции по редактированию меню 
            { 
                switch($ed)
                {
                    case 0://обновить элемент 
                    {
                        $this->updateItem($_POST["id"],$_POST["title"],$_POST["url"],$_POST["lev"]);
                        header("Location: $this->act_str");
                        break;
                    }
                    case 1://редактироват элемент 
                    {
                        return $this->editItem($id);
                        break;
                    }
                    case 2://удалить элемент 
                    {
                        $this->delItem($id);
                        header("Location: $this->act_str"); 
                        break;
                    }
                    case 3://сместить уровень влево (-1) 
                    {
                        $this->moveLeftRight($id,3);
                        header("Location: $this->act_str"); 
                        break;
                    }
                    case 4://сместить уровень вправо (+1)
                    {
                        $this->moveLeftRight($id,4);
                        header("Location: $this->act_str");
                        break;
                    }
                    case 5://сместить вверх
                    {
                        $this->moveUpDown($id,$ed);
                        header("Location: $this->act_str");
                        break;
                    }
                    case 6://сместить вниз
                    {
                        $this->moveUpDown($id,$ed);
                        header("Location: $this->act_str");
                        break;
                    }
                    case 10://удалить ссылку
                    {
                        mysql_query("UPDATE `catalog` SET `url`='' WHERE `id`='$id'");
                        header("Location: $this->act_str");
                        break;
                    }
                    default:
                    {
                        header("Location: $this->act_str");
                        break;
                    }
                }
            }
             header("Location: $this->act_str");  
         }
         
         private function moveUpDown($id,$ed)
         {

             $check_query = mysql_query("SELECT `pos` FROM `catalog` WHERE `id` = '$id'");
             $old_pos = @mysql_fetch_array($check_query); 
             $o_pos = $old_pos[0];

             
             if ($ed==5) 
             {
                 $ms=1;
                 $str_m = "MIN";
             } 
             else 
             {
                 $ms=-1;
                 $str_m = "MAX"; 
             }
             $o2_pos=$o_pos-1*$ms;
             
             $check_query = mysql_query("SELECT $str_m(`pos`) FROM `catalog`");
             $max_q=@mysql_fetch_array($check_query);
             $max= $max_q[0];
                         
             $check_query = mysql_query("SELECT `id` FROM `catalog` WHERE `pos` = '$o2_pos'");
             $new_pos_id = @mysql_fetch_array($check_query);  
             $n_pos_id = $new_pos_id[0];
             
             if ($max!=$o_pos)
             {
                 mysql_query("UPDATE `catalog` SET `pos`='$o2_pos' WHERE `id`='$id'");
                 mysql_query("UPDATE `catalog` SET `pos`='$o_pos' WHERE `id`='$n_pos_id'");                 
             }
 
             
         }
         
         private function moveLeftRight($id,$ed)
         {
             //mooove left (-1)
             $check_query = mysql_query("SELECT * FROM `catalog` WHERE `id`='$id' ");
             $item_str = @mysql_fetch_array($check_query);
             if ($item_str["levelstr"]>0 && $ed==3)
             $check_query = mysql_query("UPDATE `catalog` SET `levelstr`=`levelstr`-1  WHERE `id`= '$id'"); 

             if ($item_str["levelstr"]<2 && $ed==4) //mooove rrrright! (+1) 
             $check_query = mysql_query("UPDATE `catalog` SET `levelstr`=`levelstr`+1  WHERE `id`= '$id'");
         }
         
         
         function editItem($id)
         {
            $check_query = mysql_query("SELECT * FROM `catalog` WHERE `id`='$id' ");
             $item_str = @mysql_fetch_array($check_query);
             
             $title_old=$item_str["title"];
             $url_old=$item_str["url"];
             
             if($item_str["levelstr"]==0) $sel_0="selected=\"selected\""; else $sel_0="";
             if($item_str["levelstr"]==1) $sel_1="selected=\"selected\""; else $sel_1="";
             if($item_str["levelstr"]==2) $sel_2="selected=\"selected\""; else $sel_2="";
             
             
             $add_str = "<form method=\"post\" action=\"$this->act_str?id=$id&amp;ed=0\">
            Заголовок
            <input type=\"text\" name = \"title\" value = \"$title_old\" maxlength = \"40\"><br /> 
            Текущая ссылка: \"".$this->returnModLink($id)."\":  <strong>".$url_old."</strong> <br /> Изменить ссылку на"
            .$this->makeSelectLink().
            "<input type=\"hidden\" name=\"id\" value=\"$id\"> <a href=\"$this->act_str?id=$id&amp;ed=10\" >Удалить ссылку</a><br />
            <select name=\"lev\">
            <option value=\"0\" $sel_0>Уровень 0</option>
            <option value=\"1\" $sel_1>Уровень 1</option>
            <option value=\"2\" $sel_2>Уровень 2</option>
            </select>
            <input type=\"submit\" value = \"Сохранить\">
            </form>";  
            
            return $add_str;           
         }
         
         
         private function updateItem($id,$title,$url,$sub_id)
         {
             $title1=htmlspecialchars($title);
             if ($url=="") 
             {
                 $check_query = mysql_query("UPDATE `catalog` SET `title`='$title1', `levelstr`='$sub_id'  WHERE `id`= '$id'"); 
             }
             else 
             {
                 $url_s=$this->returnMeLink($url);
                 $check_query = mysql_query("UPDATE `catalog` SET `title`='$title1',`url`='$url_s', `levelstr`='$sub_id'  WHERE `id`= '$id'"); 
             }
             
            return "<a href= $this->act_str> back </a>";            
         }
         
         
         function delItem($id)
         {
             $check_query = mysql_query("SELECT `pos` FROM `catalog` WHERE `id` = '$id'");
             $item_str = @mysql_fetch_array($check_query);
             $check_query = mysql_query("DELETE FROM `catalog` WHERE `id` = '$id'");
             $check_query = mysql_query("UPDATE `catalog` SET pos=pos-1 WHERE `pos`>$item_str[0] ORDER BY `pos` ASC"); 
            
         }
         
         public function makeLinkTree()
         {
             $sec_query=mysql_query("SELECT * FROM `section` ORDER BY `pos`");
             while($lines=mysql_fetch_array($sec_query)) 
             {
                 $subsec_query=mysql_query("SELECT * FROM `subsection` WHERE `p_id`=$lines[id] ORDER BY `pos` ASC");
                 //$current_tree_node=htmlspecialchars($lines["title"]);
                 //$str.=$lines["id"]."<br />"; 
                 $str[]=$lines["id"];
                 $titleStr[]= $lines["title"];
                 while($sublines=mysql_fetch_array($subsec_query))
                 {
                    //$str = $str.$lines["id"].";".$sublines["id"]."<br />";
                    $str[]=$lines["id"].";".$sublines["id"];
                    $titleStr[]="&nbsp;&nbsp;".$sublines["title"]; 
                 }
                 $arr["links"]=$str;
                 $arr["titles"]=$titleStr;
             }
             return $arr;
         }
         
         function returnMeLink($ids)
         {
             $st1 = explode(";",$ids);
             
             if (count($st1)==1)
             {
                 $l=mysql_query("SELECT * FROM `section` WHERE `id`=$st1[0]");
                 $l1=mysql_fetch_array($l);
                 $l12=str_replace("/","",$l1["link"]); 
                 return "/".$l12."/";  
             }
             else
             {
                $l=mysql_query("SELECT * FROM `section` WHERE `id`=$st1[0]");
                $l1=mysql_fetch_array($l);
                $l12=str_replace("/","",$l1["link"]);
                $l=mysql_query("SELECT * FROM `subsection` WHERE `id`=$st1[1]");
                $l2=mysql_fetch_array($l);
                $l3=str_replace("/","",$l2["link"]);
                return "/".$l12."/".$l3."/";
             }
             
         }
        
        function makeSelectLink()
        {
            /*"<select name=\"lev\">
            <option value=\"0\" $sel_0>Уровень 0</option>
            <option value=\"1\" $sel_1>Уровень 1</option>
            <option value=\"2\" $sel_2>Уровень 2</option>
            </select>"; */
            $wtfkArray = $this->makeLinkTree();
            $titleArr = $wtfkArray["titles"];
            $linksArr = $wtfkArray["links"];
            $i=0; 
            //$link=$this->returnModLink($id); 
            $resSelect = $resSelect."<option value=\"\" selected=\"selected\">&nbsp;&nbsp;&nbsp;&nbsp;</option>\n"; 
            while ($i<count($titleArr))       
            {
                $resSelect = $resSelect."<option value=\"".$linksArr[$i]."\">"
                .$titleArr[$i]."</option>\n";
                //echo $link; 
                ++$i;
            }    
            $resSelect="<select name=\"url\">".$resSelect."</select>\n";
            return $resSelect;            
        }
        
        function returnModLink($id)
        {
            $idQuery=mysql_query("SELECT * FROM `catalog` WHERE `id`='$id'");
            $linkStr=mysql_fetch_array($idQuery);
            $linkArray=explode("/",$linkStr["url"]);
            //echo "now $linkStr[url]<br />";
            $f=$linkArray[1];
            //$s=$linkArray[2];
            $f_i_q=mysql_query("SELECT * FROM `section` WHERE `link`='/$f/'");
            $f_i=mysql_fetch_array($f_i_q);
           // $firstId=$f_i["id"];
            return $f_i["title"];
           /* if ($s!="")
            {
                $s_i_q=mysql_query("SELECT * FROM `subsection` WHERE `link`='/$s/' AND `p_id`='$firstId'");
                $s_i=mysql_fetch_array($s_i_q);            
                $secondId=$s_i["id"];
            } */
            //return $firstId.";".$secondId;
        }
        
    }
?>
