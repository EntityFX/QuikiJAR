<?php
    require_once("captcha.php");
    class AnswerQuestion
    {    /*
        help
        пользовательская часть:
        userQuests() -- выведет список отвеченных вопросов
        addQuestion($_POST["name"],$_POST["mail"],$_POST["question"]); -- выведет форму для добавления вопроса
        
        админская часть:
        admQuests($_GET["e"],$_GET["id"]) -- в зависимости от передаваемых параметров выдаст список вопросов, редактирование, удаление, и ответить
        */
        private $act_str;
                
        function __construct($address)
        {
            $this->act_str=$address;
            $add_query = mysql_query("CREATE TABLE IF NOT EXISTS `anque` (
            `id` int(11) NOT NULL auto_increment,
            `name` varchar(255) default NULL,
            `email` varchar(255) default NULL,
            `question` varchar(255) NOT NULL,
            `answer` varchar(255) default NULL,
            PRIMARY KEY  (`id`)
            ) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1");
           
        }
        
        public function userQuests()
        {
            return $this->showQuestions(1,"","");
        }
        
        public function admQuests($e,$id)
        {
            return $this->showQuestions(0,$e,$id);
        }
        
        public function addQuestion($name,$mail,$question)
        {
            $name = htmlspecialchars($name); 
            $email = htmlspecialchars($email); 
            $question = htmlspecialchars($question);
            $add_str = "<form id=\"ask\" method=\"post\" action=\"$this->act_str\">
                            <h2>Задайте свой вопрос</h2>
                            <div><dl>
                                <dd><label for=\"aname\">Имя:</label></dd>
                                <dt><input type=\"text\" name = \"name\" id=\"aname\" value = \"\" maxlength = \"40\" /></dt>
                                <dd><label for=\"aemail\">E-mail:</label></dd>
                                <dt><input id=\"aemail\" type=\"text\" name = \"email\" value = \"\" maxlength = \"40\" /></dt>
                                <dd><label for=\"aquestion\">Ваш вопрос: <span style=\"color: red; font-size: 22px;\" >*</span></label></dd>
                                <dt><textarea id=\"aquestion\" name=\"question\" rows=\"5\" cols=\"50\"></textarea></dt>
                                <dd>&nbsp;</dd>
                                <dt><img src=\"/includes/captcha_create.php\" alt=\"CAPTCHA\" /></dt>
                                <dd><label for=\"acaptcha\">Код на картинке:</label></dd>
                                <dt><input id=\"acaptcha\" type=\"text\" name = \"captcha\" value = \"\" maxlength = \"6\" /></dt>
                                <dd>&nbsp;</dd>
                                <dt><span style=\"color: red;\">*</span> - обязательное для заполнения</dt>
                                <dt><input type=\"submit\" value = \"Отправить\" /></dt>
                            </dl></div>
                        </form>";
            if ($question!="" & TCaptcha::check_captcha($_POST["captcha"]))
            {
                $add_query = mysql_query("INSERT INTO `anque` VALUES(0,'$name','$email','$question',0)");  
            }
            return $add_str;
        }
        
        public function showQuestions($adm,$e,$id)
        {
            $res_str="";
            if ($e=="" & $id=="") 
            {
                switch($adm)
                {
                    case 0://для админа
                        $query=mysql_query("SELECT * FROM `anque`");
                        while($item_str = @mysql_fetch_array($query))
                        {
                            $res_str=$res_str."<b>Вопрос</b>: &nbsp;".$item_str["question"]
                            ."<br />Имя: &nbsp;".$item_str["name"]."<br />e-mail:&nbsp;"
                            .$item_str["email"]."<br /><b>Ответ:</b><br />"
                            .$item_str["answer"]."<br /> 
                            <a href=\"$this->act_str?e=ans&id=".$item_str["id"]."\" >Ответить</a>&nbsp;
                            <a href=\"$this->act_str?e=edit&id=".$item_str["id"]."\">Ред</a>&nbsp;
                            <a href=\"$this->act_str?e=del&id=".$item_str["id"]."\">Х</a>&nbsp;<hr />";
                        }
                        break;
                    case 1://для не админа
                        $query=mysql_query("SELECT * FROM `anque`");
                        while($item_str = @mysql_fetch_array($query))
                        { 
                            if ($item_str["answer"]!="0")
                            {
                                $res_str=$res_str."<div class=\"question\"><strong>Имя:</strong> $item_str[name]<br /><strong>Вопрос:</strong>&nbsp;<i>".$item_str["question"]."</i><br /><strong>Ответ:</strong>&nbsp;<i>".$item_str["answer"]."</i><br /></div>";
                            }
                        }
                        break;
                    default:

                    break;
                }  
            }
            //if ($e=="del" & $id!="") $res_str= "sss";//$res_str = $this->delItem($id);
            if ($e=="del" & $id!="" & $adm==0) $res_str= $this->delItem($id); 
            if ($e=="edit" & $id!="" & $adm==0) $res_str= $this->editItem($id);
            if ($e=="ans" & $id!="" & $adm==0) $res_str= $this->editItem($id);
            if ($e=="upd" & $id!="" & $adm==0) 
            {
                $res_str= $this->updateItem($_POST["id"],$_POST["name"],$_POST["email"],$_POST["question"],$_POST["answer"]); 
                header("Location: $this->act_str");   
            }
           
        return $res_str;
        }
        
         
        private function updateItem($id,$name,$email,$question,$answer)
        {
            $name=htmlspecialchars($name);
            $email=htmlspecialchars($email);
            $question=htmlspecialchars($question);
            $answer=htmlspecialchars($answer);
            mysql_query("UPDATE `anque` SET `name`='$name', `email`='$email', `question`='$question', `answer`='$answer' WHERE `id`= '$id'");
            //echo $id,$name,$email,$question,$answer;
            //return "<a href= \"$this->act_str\"> back </a>";            
        }
        
        private function editItem($id)
        {
            $query=mysql_query("SELECT * FROM `anque` WHERE `id`='$id'");
            $item_str = @mysql_fetch_array($query);
            $name=$item_str["name"];
            $email=$item_str["email"];
            $question=$item_str["question"];
            $answer=$item_str["answer"];
            $str="<form method=\"post\" action=\"$this->act_str?e=upd&id=$id\">
            Имя
            <input type=\"text\" name = \"name\" value = \"$name\" maxlength = \"40\"><br /> 
            e-mail 
            <input type=\"text\" name = \"email\" value = \"$email\" maxlength = \"40\"><br />
            Ваш вопрос:<br /> <textarea name=\"question\" rows=\"5\" cols=\"40\">$question</textarea><br />
            Ответ:<br /> <textarea name=\"answer\" rows=\"5\" cols=\"40\">$answer</textarea><br />
            <input type=\"hidden\" name=\"id\" value=\"$id\"> 
            <input type=\"submit\" value = \"Ок\">
            </form>";
            if ($question!="" & $answer!="")
            {
                mysql_query("UPDATE `anque` SET `question`='$question',`answer`='$answer' WHERE `id`='$id'");
            }
            return $str;
        }
                 
        private function delItem($id)
        {
             $check_query = mysql_query("DELETE FROM `anque` WHERE `id` = '$id'"); 
             return "Удалено. <a href= \"$this->act_str\"> Back </a>" ;
        }
    }   
?>
