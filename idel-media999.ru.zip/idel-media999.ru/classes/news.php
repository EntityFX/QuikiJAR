<?
    /*

	*/
	require_once "date.php"; 
	class TNews {
	
		function show_some_news_or_one_u(){
			return $this->read_news(1,1);
		}
		
		function show_some_n_a(){
			return $this->read_news(0,2);
		}
        function add_news() {
			$str_form = "<div class=\"panel\"><form action=\"/control/news/add\" method=\"post\">
				<dl>
				<dt><label for=\"logo\">Заголовок:</label></dt>
				<dd><input type=\"text\" name=\"title\" size=\"40\" maxlength=\"256\" id=\"logo\" /></dd>
				<dt><label for=\"link_memo\">Текст:</label></dt>
				<dd><textarea name=\"txt\" cols=\"60\" rows=\"7\" id=\"link_memo\"></textarea></dd>
				<dt>&nbsp;</dt>
				<dd><input type=\"submit\" value=\"Сохранить\" /> 
				<input type=\"reset\" value=\"Очистить\" /></dd></dl>
				</form></div>";
			
			
			$article_title = htmlspecialchars($_POST["title"]);
			$article_txt = htmlspecialchars($_POST["txt"]);
			if ($article_title != "" and $article_txt !=""){
				$users_sec_query=mysql_query("INSERT INTO `news`SET `date`=NOW(), 
				`title`= '$article_title', `text`= '$article_txt' ");
				return "Новость успешно добавлена!";
			}else{
				return $str_form;
			}			
			
		}
		
		
		//если $adm = 0, то в режиме администратора
		//если $adm = 1, то в режиме обычного юзера
		//$st - переменная показывает где применяется функция
		
		//$adm = 1; $st = 1; применяется обычными юзерами при просмотре всех новостей. внизу будет ссылки со списками групп новостей
		//$adm = 0; $st = 2; для админов. показывает в разделе контроля. с ссылками на редактирование и удаление
		function read_news($adm, $st){
			$date=new TDate();
			$back_str = "/news.";
			$query_nums=mysql_query("select count(*) as count from `news`");
			$counts=mysql_fetch_array($query_nums);
			$edit_news="";
			$num=0;
			$newsid=$_GET["n"];//покажет отдельную новость
			$newscnt=$_GET["i"];//показывает листинг по пять штук, например
			
			$newscnt = $this->trans($newscnt);			
			$newsid = $this->trans($newsid);
			
			$newscnt_n = ($newscnt-1)*5;  //цифра 5 - количество выводимых новостей
			$n_nums = 5;
			$news_groups = ceil($counts[0] / $n_nums);
			
			if ($newscnt != "" and $newsid == ""){//показываем список новостей
				$query_news=mysql_query("SELECT * FROM `news` GROUP BY `date` DESC LIMIT $newscnt_n,5");
				while ($cnt_sec=mysql_fetch_array($query_news)) {
					$datelink = $cnt_sec[0];
					if (strlen($cnt_sec[3]) < 50 ){
						$news_str = substr($cnt_sec[3],0,50)."&nbsp; &nbsp;";
					}else{
						$news_str = substr($cnt_sec[3],0,50)."... ";
					}
					if ($adm == 0) {
						$del_news = "<a href =\"/control/news/del/?id=$cnt_sec[0]\" class=\"del\">X</a>";
						$edit_news = "<a href =\"/control/news/edit/?id=$cnt_sec[0]\">Ред.</a>";
					}else{
						$del_news = "";
						$edit_news = "";
					}
					if ($st == 1){
						$news_link = "/news/?n=$datelink";
					}
					
					if ($st == 2){
						$news_link = "/control/news/?n=$datelink";
					}
					$cool_date=$date->get_cool_date($cnt_sec[1]);
					$message_table=$message_table."<table border=\"0\">
					<tr><td><a href=\"$news_link\">$cool_date</a>$edit_news $del_news</td></tr>
					<tr><td><a href=\"$news_link\"><b>$cnt_sec[2]</b></a></td></tr>
					<tr><td>$news_str<a href=\"$news_link\">&gt;&gt;</a></td></tr>
					</table> <br />";
				}
				for($cnt=1;$cnt<=$news_groups;$cnt++){//формируем ссылки
					if ($st == 1){
						if ($cnt != $newscnt){ 
							$message_table= $message_table."<a href=\"/news/?i=$cnt\"> [$cnt] </a>";
						}else{
							$message_table= $message_table."$cnt";
						}
					}
					if ($st == 2){
						if ($cnt != $newscnt) {
							$message_table= $message_table."<a href=\"/control/news/?i=$cnt\"> [$cnt] </a>";
						}else{
							$message_table= $message_table."$cnt";
						}
					}
				}
				return $message_table;
			}
			if ($newscnt == "" and $newsid != ""){//показываем новость
				$query_news=mysql_query("SELECT * FROM `news` WHERE `id` = '$newsid'");
				$cnt_sec=mysql_fetch_array($query_news);
				if ($adm == 0) {
					$del_news = "<a href =\"/control/news/del/?id=$cnt_sec[0]\" class=\"del\">X</a>";
					$edit_news = "<a href =\"/control/news/edit/?id=$cnt_sec[0]\">Ред.</a>";
					$back_str = "/control/news/";
				}else{
					$del_news = "";
					$edit_news = "";
					$back_str = "/news";
				}
				$cool_date=$date->get_cool_date($cnt_sec[1]);
				$message_table="<table border=\"0\">
				<tr><td>$cool_date $edit_news $del_news</td></tr>
				<tr><td><b>$cnt_sec[2]</b></td></tr>
				<tr><td>$cnt_sec[3]</td></tr>
				</table> <br /><a href=\"$back_str\">К списку новостей</a>";
				return $message_table;
			}
			if ($newscnt == "" and $newsid == ""){//показываем список новостей
				$query_news=mysql_query("SELECT * FROM `news` GROUP BY `date` DESC LIMIT 0,5");
				while ($cnt_sec=mysql_fetch_array($query_news)) {
					if ($adm == 0) {
						$del_news = "<a href =\"/control/news/del/?id=$cnt_sec[0]\" class=\"del\">X</a>";
						$edit_news = "<a href =\"/control/news/edit/?id=$cnt_sec[0]\">Ред.</a>";
					}else{
						$del_news = "";
						$edit_news = "";
					}
					$datelink = $cnt_sec[0];
					$news_str=iconv("UTF-8", "WINDOWS-1251",$cnt_sec[3]);
					$news_str=substr($news_str,0,50);
					$news_str=iconv("WINDOWS-1251","UTF-8",$news_str);
					$cool_date=$date->get_cool_date($cnt_sec[1]);
					$message_table=$message_table."<table border=\"0\">
					<tr><td>$cool_date$edit_news $del_news</td></tr>
					<tr><td><a href=\"/news/?n=$datelink\"><b>$cnt_sec[2]</b></a></td></tr>
					<tr><td>$news_str <a href=\"/news/?n=$datelink\">&gt;&gt;</a></td></tr>
					</table> <br />";
				}
				for($cnt=1;$cnt<=$news_groups;$cnt++){//формируем ссылку
					if ($st == 1){
						if ($cnt == 1) 
						$message_table= $message_table."$cnt";
						else
						$message_table= $message_table." <a href=\"/news/?i=$cnt\">[$cnt]</a>";
					}
					
					if ($st == 2){
						if ($cnt == 1) 
						$message_table= $message_table."$cnt";
						else
						$message_table= $message_table." <a href=\"/control/news/?i=$cnt\">[$cnt]</a>";
					}
				}
				
				return $message_table;
			}
		}
		
		function show_simple_news(){
			$query_news=mysql_query("SELECT * FROM `news` GROUP BY `date` DESC LIMIT 0,5");
			while ($cnt_sec=mysql_fetch_array($query_news)) {
				$datelink = $cnt_sec[0];
				$news_str=iconv("UTF-8", "WINDOWS-1251",$cnt_sec[3]);
				$news_str=substr($news_str,0,50);
				$news_str=iconv("WINDOWS-1251","UTF-8",$news_str); 
				$date=new TDate();
				$cool_date=$date->get_cool_date($cnt_sec[1]);
				$message_table=$message_table."<div class=\"news_br\"><a href=\"/news/?n=$datelink\"><b>$cnt_sec[2]</b></a>
				<span class=\"date\">$cool_date</span>
				$news_str...<a href=\"/news/?n=$datelink\">&gt;&gt;</a>
				</div>";
			}
			$message_table= $message_table."<a href=\"/news/\"> Читать все новости</a>";
			return $message_table;
		}
		
		function del_news(){
			$del_news_id=$_GET["id"];
			$this->trans($del_news_id);
			if ($del_news_id != ""){
				$query_for_del = mysql_query("DELETE FROM `news` WHERE `id` = '$del_news_id'");
				//$cnt_sec=mysql_fetch_array($query_for_del);
				return "Новость успешно удалена";
				header("Location: /news");
			}
		}

		function edit_n(){
			$edit_news_id=$_GET["id"];
			$title_news = htmlspecialchars($_POST["title"]);
			$text_news = htmlspecialchars($_POST["txt"]);
			$news_post_id = htmlspecialchars($_POST["nums"]);
			$news_post_timest = htmlspecialchars($_POST["timest"]);
			$edit_news_id = $this->trans($edit_news_id);
			$query_news_ed = mysql_query("SELECT * FROM `news` WHERE `id` = '$edit_news_id'");
			$cnt_sec = mysql_fetch_array($query_news_ed);
			$news_date = $cnt_sec[1];
			$news_id = $cnt_sec[0];
			
			$edit_form = "<div class=\"panel\">$news_date<form action=\"/control/news/edit\" method=\"post\">
				<dl>
					<dt><label for=\"header\">Заголовок:</label></dt>
					<dd><input type=\"text\" name=\"title\" size=\"40\" maxlength=\"256\" value=\"$cnt_sec[2]\" id=\"header\" /></dd>
					<dt><label for=\"link_memo\">Текст:</label></dt>
					<dd><textarea name=\"txt\" cols=\"60\" rows=\"7\" id=\"link_memo\">$cnt_sec[3]</textarea></dd>
					<dt>&nbsp;</dt>
					<dd><input type=\"submit\" value=\"Сохранить\" /> 
					<input type=\"reset\" value=\"Очистить\" /></dd>
					<dt>&nbsp;</dt><dd><input type=\"hidden\" value=\"$news_id\" name=\"nums\" /></dd>
					<dt>&nbsp;</dt><dd><input type=\"hidden\" value=\"$news_date\" name=\"timest\" /></dd>
				</dl>
				</form></div>";
				
			if ($title_news != "" and $text_news != "" and $news_post_id != "" and $news_post_timest != ""){
				$query_news_ed=mysql_query("UPDATE `news` SET `date` = '$news_post_timest' ,
				`title` = '$title_news',
				`text` = '$text_news' WHERE `id` = '$news_post_id'");
				header("Location: /control/news");
				return true;
			}else{
				if ($edit_news_id != "") {
					return $edit_form;
				}
			}
		}
		
		function trans($st) {
			$lit = array(
			"-" => "",
			"!" => "",
			"№" => "",
			";" => "",
			":" => "",
			"@" => "",
			"#" => "",
			"$" => "",
			"%" => "",
			"&" => "",
			"?" => "",
			"~" => "",
			"`" => "",
			"'" => "",
			"\"" => "",
			" " => "",
			"_" => "",
			"[" => "",
			"]" => "",
			"{" => "",
			"}" => "",
			);
			return $st = strtr($st, $lit);
		}
	}
?>