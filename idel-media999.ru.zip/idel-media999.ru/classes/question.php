<?
	require_once("string.php");
	class TQuestion {
		private $sum=0;
		
		public function show_one_q_u(){
			return $this->read_qst(1,1);
		}
		
		public function show_all_qs_u(){
			return $this->read_qst(0,1);
		}
		
		public function show_result_one_q_u($id){
			if (ereg("([0-9])",$id,$buff)){
				return $this->rev_q(0,1,$id);
			}
		}
		
		public function vote_u() {
			$this->add_question(1,"vote");
		}
		
		public function make() {
			return $this->add_question(0,"type");
		}
		
		public function save() {
			return $this->add_question(0,"view");
		}
		
		public function show_all_q_a(){
			return $this->read_qst(0,0);
		}
		
		public function show_one_q_a(){
			return $this->read_qst(0,1);
		}
		
		public function delete($id){
			return $this->del_qst($id);
		}	

		public function add_new_q_a(){
			return $this->add_question(0,"add");
		}
		
		public function edit_q_a($id){
			return $this->edit_qst($id);
		}
		
		public function null_one($id){
			if (ereg("([0-9])",$id,$buff)){
				return $this->null_res(0,$id);
			}
		}
		
		public function null_all(){
			return $this->null_res(1,0);
		}
		
		private function null_res($much, $quest_id){
			if ($much == 0){
				$query_qs = mysql_query("SELECT * FROM `question` WHERE id = '$quest_id'");
				$cnt_sec = mysql_fetch_array($query_qs);
				$arr = split ("-", $cnt_sec[3]);
				foreach ($arr as $index => $val) {
					$arr[$index] = 0;
				}
				$res_str = implode("-",$arr);
				mysql_query("UPDATE `question` SET `stats` = '$res_str' WHERE `id`='$quest_id'");
			}else{
				$query_qs = mysql_query("SELECT * FROM `question`");
				while ($cnt_sec = mysql_fetch_array($query_qs)){
					$arr = split ("-", $cnt_sec[3]);
					foreach ($arr as $index => $val) {
						$arr[$index] = 0;
					}
					$res_str = implode("-",$arr);
					mysql_query("UPDATE `question` SET `stats` = '$res_str' WHERE `id`='$cnt_sec[0]'");
				}
			}
		}
		
		
        private function add_question($adm,$options) {
			switch ($options){
				case "add":
				if ($adm == 0){
						$options=TNewString::numbers("<option>",2,30,"</option>");
						$ad_q_form = "<div class=\"panel\"><h2 class=\"userok\">Добавить опрос</h2><form action=\"/control/questions/add\" method=\"post\">
						Выберите число вариантов ответа:
						<select name=\"num\">
						$options	
						</select><br />
						<input type=\"submit\" value=\"Добавить\" /> 
						</form></div>";
						return $ad_q_form;
					}
					break;
				case "type":
					$quest_num = $_POST["num"];
					if ($quest_num<=0 || $quest_num>99) $quest_num=1;
					if ($adm == 0){
					if ($quest_num !=""){
						for($cnt=1;$cnt<=$quest_num;$cnt++){
							$formsq = $formsq."<li><input type=\"text\" name=\"a[]\" size=\"48\" maxlength=\"256\" /><input type=\"button\" value=\"X\"onclick='del(this);' /></li>\n";
						}
						$spisok_q_form = "<div class=\"panel\"><h2 class=\"userok\">Добавление опроса</h2><form action=\"/control/questions/save\" method=\"post\">
                        <div>
						    Вопрос:<br />
						    <input type=\"text\" name=\"qst\" size=\"51\" maxlength=\"256\" /><br />
						    Варианты ответов:<br />
						    <ul id=\"qu_list\">
							    $formsq
						    </ul>
							    <input value=\"+\" type=\"button\" onclick='add(true);' />
							    <input name=\"add_cnt\" value=\"1\" type=\"text\" id=\"small_edit\" />
							    <input value=\"Очистить\" type=\"button\" onclick='clr();' /><br />
							    <input type=\"submit\" value=\"Сохранить\" />
                        </div>
						</form></div>";
						return $spisok_q_form;
					}
					break;}else{
						header("location: /");
						break;
					}
				case "view":
					if ($adm == 0){
						$arr_answrs = $_POST['a'];
						$questn = $_POST['qst'];
						$i = 0;
						foreach ($_POST['a'] as $name){
							$print_op = $print_op."$name\n";
							$vote_arr[] = 0;
							$i++;
						}
						
						$print_op = htmlspecialchars($print_op);
						$questn = htmlspecialchars($questn); 
						$vote_str = implode("-",$vote_arr);
						if (mysql_query("INSERT INTO `question` SET `title`= '$questn',
						`text`= '$print_op', `stats`= '$vote_str' ")){
							return "0";
						}else{
							return "1";
						}
					}else{
						break;
					}
				case "vote":
					return $this->vote_q();
					break;
				case "show":
					return $this->read_qst(0,$adm);
					break;
				case "del":
					return $this->del_qst($adm);
					break;
				default:
					return $q_urls;
			}
		}
		
        public function update(){
                $arr_answrs = $_POST['a'];
                $questn = $_POST['qst'];
                $id_q = $_POST['nums'];
                $i = 0;
                foreach ($_POST['a'] as $name){
                    $print_op = $print_op."$name\n";
                    $vote_arr[] = "0";
                }
                
                $print_op = htmlspecialchars($print_op);
                $questn = htmlspecialchars($questn); 
                $vote_str = implode("-",$vote_arr);
                if (mysql_query("UPDATE `question` SET `title` = '$questn',`text`= '$print_op', `stats`='$vote_str' WHERE `id`='$id_q'")){
                    return "1";
                }else{
                    return "0";
                }
        }
		
		public function edit($id){
			$edit_qst_id = $id;
			if (ereg("([0-9])",$edit_qst_id,$buff)){
				$query_qst_ed = mysql_query("SELECT * FROM `question` WHERE `id` = '$edit_qst_id'");
				$cnt_sec = mysql_fetch_array($query_qst_ed);
				$qst_str = $cnt_sec[1];
				$qst_ans = $cnt_sec[2];
				$qst_str = "<input type=\"text\" name=\"qst\" size=\"40\" maxlength=\"256\" value=\"$qst_str\" /><br />";
				$ftchd_str = $this->rev_q(1,1,$id);
				$edit_form = "<a href=\"/control/questions\">Назад</a>\n<div style=\"border: 1px solid #555;\"><form action=\"/control/questions/update\" method=\"post\">
				Вопрос:<br />
				$qst_str<br />
				Варианты ответа:<br />
				<ul id=\"qu_list\">$ftchd_str</ul>
				<input value=\"+\" type=\"button\" onclick='add(true);' />
				<input name=\"add_cnt\" value=\"1\" type=\"text\" id=\"small_edit\" />
				<input value=\"Очистить\" type=\"button\" onclick='clr();' /><br />
				<input type=\"submit\" value=\"Изменить\" /> 
				<input type=\"hidden\" value=\"$edit_qst_id\" name=\"nums\" />
				</form></div>";
				return $edit_form;
			}
		}
		
		private function del_qst($del_qst_id){
			if (ereg("([0-9])",$del_qst_id,$buff)){
				if ($del_qst_id != ""){
					if (mysql_query("DELETE FROM `question` WHERE `id` = '$del_qst_id'")){
						return "1";
					}else{
						return "0";
					}
				}
			}else{
				return "-1";
			}
		}
		
		function vote_q(){
			
			$quest_num = $_POST["answer"];
			$quest_id = $_POST["qsti"];
			if (ereg("([0-9])",$quest_id,$buff)){
				$query_qs = mysql_query("SELECT * FROM `question` WHERE id = '$quest_id'");
				$cnt_sec = mysql_fetch_array($query_qs);
				$arr = split ("-", $cnt_sec[3]);
				foreach($arr as $index => $val){
					if ($quest_num == $index){
						$arr[$index]=$arr[$index]+1;
					}
				}
				$res_str = implode("-",$arr);
				$query_qs = mysql_query("UPDATE `question` SET `stats` = '$res_str' WHERE `id` = '$quest_id'");
			}
			return $res_str;	
		}
		
		private function read_qst($str, $adm){
			$query_nums = mysql_query("SELECT COUNT(*) FROM `question`");
			$counts = @mysql_fetch_array($query_nums);
			if ($str == 0){
				$query_qst = mysql_query("SELECT * FROM `question` GROUP BY `id` DESC");
				$it=0;
				while ($cnt_sec = @mysql_fetch_array($query_qst)) {
					++$it;
					if ($adm == 0) {
						$del_news = "<a href =\"/control/questions/del/?id=$cnt_sec[0]\" class=\"del\" title=\"Удалить опрос\">X</a>";
						$edit_news = "<a href =\"/control/questions/edit/?id=$cnt_sec[0]\" title=\"Редактировать опрос\">Ред</a>";
						$nil="<a href =\"/control/questions/null/?id=$cnt_sec[0]\" title=\"Обнулить опрос\">Обнулить</a>";
						$id_qq = $cnt_sec[0];
						$que=$this->rev_q(0,1,$id_qq);
						$s_message_table="<div style=\"border: 1px solid #555;\">$edit_news $del_news $nil<table>
						<tr><td>Всего голосов: $this->sum\n</td></tr><tr><td><h2>#$it $cnt_sec[1]</h2></td></tr>
						<tr><td><form action=\"#\">".$que."<input type=\"hidden\" name=\"qsti\" value=\"$id_qq\" />
						</form></td></tr>
						</table></div><br />";
						$message_table=$message_table.$s_message_table;						
					}else{
						$id_qq = $cnt_sec[0];
						$s_message_table="<table width=\"580\">
						<tr><td><h2>#$it $cnt_sec[1]</h2></td></tr>
						<tr><td><form action=\"/question/vote\" method = \"post\">".$this->rev_q(0,1,$id_qq)."<input type=\"submit\" id=\"golos\" value=\"Голосовать\" /> 
						<input type=\"hidden\" name=\"qsti\" value=\"$id_qq\" />
						</form></td></tr>
						</table> <br />";	
						$message_table=$message_table."Всего голосов: $this->sum\n<br />".$s_message_table;	
					}	
				}
			}else{
				$q_number = mt_rand(0,($counts[0]-1));
				$query_qst = mysql_query("SELECT * FROM `question`");
				$o_O = 0;
				while ($q_number != $o_O){
					$cnt_sec = mysql_fetch_array($query_qst);
					$o_O++;	
				}
				$cnt_sec = @mysql_fetch_array($query_qst);
				if ($cnt_sec!=0) {
					$id_qq = $cnt_sec[0];
                    $message_table="
                    <div class=\"htwo\"><h2>Опрос</h2></div>
                    <strong>$cnt_sec[1]</strong>
                    <form id=\"question\" method=\"post\" action=\"/question/vote\">
                        <div>
                        
                    ";
                    $message_table.=$this->rev_q(0,0,$id_qq);
                    $message_table.="<input type=\"submit\" id=\"golos\" value=\"Голосовать\" /><input type=\"hidden\" name=\"qsti\" value=\"$id_qq\" /></div></form>";
                    $message_table.="<a href=\"/question/all/\" style=\"margin: 5px 5px;\">Другие опросы</a>";
					//$message_table=$message_table."<table border=\"0\"><tr><td><strong>$cnt_sec[1]</strong></td></tr><tr><td><form action=\"/question/vote\" method = \"post\">".$this->rev_q(0,0,$id_qq)."<input type=\"submit\" id=\"golos\" value=\"Голосовать\" /><input type=\"hidden\" name=\"qsti\" value=\"$id_qq\"></form></td></tr></table>";
				} else $message_table="";
			}
			return $message_table;
			
		}

		private function rev_q ($type_or_show, $st, $quest_id ){
			$query_qs = mysql_query("SELECT * FROM `question` WHERE id = '$quest_id'");
			$cnt_sec = mysql_fetch_array($query_qs);
			$str_a = $cnt_sec[2];
			$nums = 0;
			$str_exp = explode("\n",$str_a);
			$arr = split ("-", $cnt_sec[3]);
			$o_O = count($arr);
			$summ=0;
			$summ=array_sum($arr);
			$this->sum=$summ;
			if ($summ != 0){
				for ($i=0;$i<$o_O;$i++){
					$temp_arr[$i] = round($arr[$i]/$summ,3)*100;
				}
			}else{
				for ($i=0;$i<$o_O;$i++){
					$temp_arr[$i] = 0;
				}
			}
			do {
				$q++;
				if ($type_or_show == 0){
					if ($st == 1){
						$stat_str = "[".$temp_arr[$nums]."]";
						$tempstr = $tempstr."<div><input type=\"radio\" class=\"niceRadio\" name=\"answer\" value=\"$nums\" /><label>".$str_exp[$nums]."&nbsp; &nbsp;[".$temp_arr[$nums]."%]</label></div>";
					}else{
                        $tempstr.="<li><input type=\"radio\" class=\"niceRadio\" name=\"answer\" value=\"$nums\" /><label>$str_exp[$nums]</label></li>";
					}
				}else{
					$tempstr = $tempstr."<li><input type=\"text\" name=\"a[]\" size=\"40\" maxlength=\"256\" value=\"$str_exp[$nums]\" /><input type=\"button\" value=\"X\"onclick='del(this);' /></li>";
				}
				$nums++;
			}while (count($str_exp)>$nums+1);
			return "<ul>".$tempstr."</ul>";
		}
	}
?>